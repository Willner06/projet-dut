<?php $__env->startSection('content'); ?>

<div>
    <div class="pagetitle">
        <div class="">
            <h1>Histotique des Connexions</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Historique des Connections</li>
                </ol>
            </nav>
        <br><br>
        </div>

    </div><!-- End Page Title -->



    <div class="card">
        <div class="card-body">
          

          <!-- Bordered Tabs Justified -->
          <ul class="nav nav-tabs nav-tabs-bordered d-flex" id="borderedTabJustified" role="tablist">
            <li class="nav-item flex-fill" role="presentation">
              <button class="nav-link w-100 active" id="home-tab" data-bs-toggle="tab" data-bs-target="#bordered-justified-home" type="button" role="tab" aria-controls="home" aria-selected="true">Tout</button>
            </li>
            <li class="nav-item flex-fill" role="presentation">
              <button class="nav-link w-100" id="profile-tab" data-bs-toggle="tab" data-bs-target="#bordered-justified-profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Connections</button>
            </li>
            <li class="nav-item flex-fill" role="presentation">
              <button class="nav-link w-100" id="contact-tab" data-bs-toggle="tab" data-bs-target="#bordered-justified-contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Déconnection</button>
            </li>
          </ul>
          <div class="tab-content pt-2" id="borderedTabJustifiedContent">
            <div class="tab-pane fade show active" id="bordered-justified-home" role="tabpanel" aria-labelledby="home-tab">
                <div class="table-responsive card">
                    <table class="datatable">
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th>Date</th>
                                <th>Heure</th>
                                <th>Utilisateur</th>
                                <th>Connection/Déconnection</th>
                                
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($id++); ?></td>
                                <td><?php echo e($log->date->format('d-m-Y')); ?></td>
                                <td><?php echo e($log->heure->format('H:i:s')); ?></td>
                                <td><?php echo e($log->user->nom." ".$log->user->prenom); ?></td>
                                <?php if($log->login == true): ?>
                                <td class=" text-success">Connection</td>
                                <?php else: ?>
                                <td class="text-danger">Déconnection</td>
                                <?php endif; ?>

                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>

                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="bordered-justified-profile" role="tabpanel" aria-labelledby="profile-tab">
                <div class="table-responsive card">
                    <table class="datatable">
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th>Date</th>
                                <th>Heure</th>
                                <th>Utilisateur</th>
                                <th>Connection/Déconnection</th>
                                
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $logins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $login): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($id++); ?></td>
                                <td><?php echo e($login->date->format('d-m-Y')); ?></td>
                                <td><?php echo e($login->heure->format('H:i:s')); ?></td>
                                <td><?php echo e($login->user->nom." ".$login->user->prenom); ?></td>
                                <?php if($login->login == true): ?>
                                <td class=" text-success">Connection</td>
                                <?php else: ?>
                                <td class="text-danger">Déconnection</td>
                                <?php endif; ?>

                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>

                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="bordered-justified-contact" role="tabpanel" aria-labelledby="contact-tab">
                <div class="table-responsive card">
                    <table class="datatable">
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th>Date</th>
                                <th>Heure</th>
                                <th>Utilisateur</th>
                                <th>Connection/Déconnection</th>
                                
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $logouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($id++); ?></td>
                                <td><?php echo e($logout->date->format('d-m-Y')); ?></td>
                                <td><?php echo e($logout->heure->format('H:i:s')); ?></td>
                                <td><?php echo e($logout->user->nom." ".$logout->user->prenom); ?></td>
                                <?php if($logout->login == true): ?>
                                <td class=" text-success">Connection</td>
                                <?php else: ?>
                                <td class="text-danger">Déconnection</td>
                                <?php endif; ?>

                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>

                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
          </div><!-- End Bordered Tabs Justified -->

        </div>
      </div>




    <div class="row">

    </div>

</div>



<?php if(Session::has('message')): ?>

<script>
    toastr.success("<?php echo Session::get('message'); ?>");
</script>

<?php endif; ?>


<?php if($errors->all()): ?>

<script>
    toastr.error("Une erreur c'est produite");
</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appTiers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion8.9\resources\views/user/logs.blade.php ENDPATH**/ ?>