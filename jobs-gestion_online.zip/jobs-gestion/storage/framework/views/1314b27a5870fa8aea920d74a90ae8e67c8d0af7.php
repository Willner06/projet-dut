
<?php $__env->startSection('content'); ?>

<h1>Tiers</h1>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appTiers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion6.9\resources\views/tiers/home.blade.php ENDPATH**/ ?>