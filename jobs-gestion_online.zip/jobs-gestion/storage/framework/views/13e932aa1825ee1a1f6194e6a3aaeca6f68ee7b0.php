<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('caisse.home')); ?>">
          <i class="bi bi-grid"></i>
          <span>Tableau de bord</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>Formulaire</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="<?php echo e(route('caisse.encaissement.index')); ?>">
              <i class="bi bi-circle"></i><span>Encaissement</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('caisse.decaissement.index')); ?>">
              <i class="bi bi-circle"></i><span>Decaissement</span>
            </a>
          </li>
        </ul>
      </li><!-- End Components Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('caisse.decaissement.transport')); ?>">
          <i class="bi bi-person"></i>
          <span>Fiche de transport</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('caisse.decaissement.communication')); ?>">
          <i class="bi bi-person"></i>
          <span>Fiche de communication</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('caisse.decaissement.carburant')); ?>">
          <i class="bi bi-person"></i>
          <span>Fiche carburant</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('caisse.clotureDeCaisse')); ?>">
          <i class="bi bi-question-circle"></i>
          <span>Fiche de clôture de caisse</span>
        </a>
      </li><!-- End F.A.Q Page Nav -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('caisse.suivi.index')); ?>">
          <i class="bi bi-circle"></i><span>Tableur de suivi de caisse</span>
        </a>
      </li>


      

  </aside><!-- End Sidebar-->
<?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion7.0\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>