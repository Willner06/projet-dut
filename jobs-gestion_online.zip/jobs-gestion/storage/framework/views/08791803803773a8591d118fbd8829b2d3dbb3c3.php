<?php $__env->startSection('content'); ?>

<div>
    <div class="pagetitle">
        <div class="">
            <h1>Autres tiers</h1>
            <div class="card float-end">
                <button class="badge text-bg-success m-3" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalToggle"> <i class="bi bi-plus-lg"></i> Autre tier </button>
            </div>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active">Autres tiers</li>
                </ol>
            </nav>
        <br><br>
        </div>

    </div><!-- End Page Title -->

    <div class="row">
        <div class="table-responsive card">
            <table class="datatable">
                <thead>
                    <tr>
                        <th>Numéro client</th>
                        <th>Nom(s)</th>
                        <th>Prénom(s)</th>
                        <th>Nif</th>
                        <th>Localisation</th>
                        <th>Téléphone</th>
                        <th>Mail</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tier->numero); ?></td>
                        <td><?php echo e($tier->nom); ?></td>
                        <td><?php echo e($tier->prenom); ?></td>
                        <td><?php echo e($tier->nif); ?></td>
                        <td><?php echo e($tier->localisation); ?></td>
                        <td><?php echo e($tier->telephone); ?></td>
                        <td><?php echo e($tier->mail); ?></td>
                        <td>
                            <a href="<?php echo e(route('tier.show', $tier->id)); ?>" class=" text-bg-warning badge">Voir</a>

                            <form class="d-inline" action="<?php echo e(route('tier.delete',$tier->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="text-bg-danger badge" onclick="return confirm('Êtes vous sûr de vouloir supprimer?')">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>

                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
                <form class="row g-3 needs-validation" novalidate method="post" action="<?php echo e(route('tiers.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class=""><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="col-md-12">
                        <label for="type_compte" class="form-label">Code Comptable</label>
                        <select class="form-select" id="type_compte" name="type_compte" required>
                            <option  value="Personnel">Personnel</option>
                            <option  value="Organismes sociaux">Organismes sociaux</option>
                            <option  value="Etat et collectivités publiques">Etat et collectivités publiques</option>
                            <option  value="Organismes internationaux">Organismes internationaux</option>
                            <option  value="Apporteurs, associés et groupe">Apporteurs, associés et groupe</option>
                            <option  value="Débiteurs et créditeurs divers">Débiteurs et créditeurs divers</option>
                            <option  value="Créances et dettes hors activités ordinaires (HAO)">Créances et dettes hors activités ordinaires (HAO)</option>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <label for="nom" class="form-label">Nom</label>
                        <input type="text" class="form-control" id="nom" name="nom" required>
                    </div>
                    <div class="col-md-12">
                      <label for="prenom" class="form-label">Prénom</label>
                      <input type="text" class="form-control" id="prenom" name="prenom">
                    </div>
                    <div class="col-md-6">
                        <label for="telephone" class="form-label">Téléphone</label>
                        <input type="text" class="form-control" id="telephone" name="telephone">
                    </div>
                    <div class="col-md-6">
                        <label for="mail" class="form-label">Mail</label>
                        <input type="email" class="form-control" id="mail" name="mail">
                    </div>
                    <div class="col-md-12">
                      <label for="nif" class="form-label">Nif</label>
                      <input type="text" class="form-control" id="nif" name="nif">
                    </div>
                    <div class="col-md-12">
                        <label for="localisation" class="form-label">Localisation</label>
                        <input type="text" class="form-control" id="localisation" name="localisation" required>
                    </div>

                    
                    <div class="col-12">
                      <button class="btn btn-success float-end" name="button" value="autre" type="submit">Valider</button>
                    </div>
                  </form>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2" tabindex="-1">

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appTiers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobs-gestion21\resources\views/tiers/indexAutre.blade.php ENDPATH**/ ?>