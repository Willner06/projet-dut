<?php $__env->startSection('content'); ?>

    <section>
        <div class="card m-4 p-4">
            ok
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion5.5\resources\views/caisse/home.blade.php ENDPATH**/ ?>