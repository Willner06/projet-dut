<?php $__env->startSection('content'); ?>

<section class="section dashboard">
    <div class="row">
        <div class="pagetitle">
            <div class="">
                <h1>Matériels amortissables</h1>
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                        <li class="breadcrumb-item active">Matériels amortissables</li>
                    </ol>
                </nav>
            </div>

            <div class="card float-end m-3">
                <div class="p-2">
                    <div class=" col-sm-6 d-inline">
                        <a class="badge text-bg-success btn" href="<?php echo e(route('materiel.export.csv')); ?>"> Exporter <i class="bi bi-file-earmark-spreadsheet"></i> </a>
                        <a class="badge text-bg-warning btn" type="button" data-bs-toggle="modal" data-bs-target="#addCategorie"> Type de matériel <i class="bi bi-plus-lg"></i></a>
                    </div>
                </div>
            </div>
        </div><!-- End Page Title -->

        <?php
        $total_mat=0;
            foreach ($categories as $categorie){
                $total_mat=$total_mat+count($categorie->materiels);
            }
        ?>


        <div class="container">
            <div class="row">


                <div class="col-sm-4">
                    <div class="card info-card sales-card">
                        <div class="card-body ">
                            <h5 class="card-title f-2">Valeur totale du matériel <!-- <span>| Today</span> --></h5>

                            <div class="d-flex align-items-center ms-5">
                              <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-currency-fca text-success"><?php echo e($monaie); ?></i>
                              </div>
                              <div class="ps-3">
                                <h6><?php echo e(number_format($cout_total ,0,'.',' ')); ?></h6>
                                

                              </div>
                            </div>
                        </div>
                    </div><!-- End Card with titles, buttons, and links -->
                </div>

                <div class="col-sm-4">
                    <div class="card info-card sales-card">
                        <div class="card-body ">
                            <h5 class="card-title f-2">Nombre totale du matériel <!-- <span>| Today</span> --></h5>

                            <div class="d-flex align-items-center ms-5">
                              <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-currency text-success"><i class="bi bi-laptop"></i></i>
                              </div>
                              <div class="ps-3">
                                <h6><?php echo e(number_format($total_mat ,0,'.',' ')); ?></h6>
                                

                              </div>
                            </div>
                        </div>
                    </div><!-- End Card with titles, buttons, and links -->
                </div>





                

                
                <div class="table-responsive bg-white">
                    <table class="table datatable ">
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th>Type de matériel</th>
                                <th>Nombre de matériel</th>
                                <th>Coût total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
<?php
    $id=1
?>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($id++); ?></td>
                                <td><?php echo e($categorie->libelle); ?></td>
                                <td><?php echo e(count($categorie->materiels)); ?></td>
                                <td>
                                    <?php
                                        $cout=0;
                                        foreach ($categorie->materiels as $mat) {
                                            $cout=$cout+$mat->cout_acquisitionTtc;
                                        }
                                    ?>
                                    <?php echo e(number_format($cout,0,'.',' ').$monaie); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('materiel.categorie.show', $categorie->id)); ?>" class=" text-bg-warning badge">Afficher</a>
                                    <form class="d-inline" action="<?php echo e(route('materiel.categorie.delete',$categorie->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class=" text-bg-danger badge" onclick=" return confirm('Êtes vous sûr de vouloir supprimer?')">Supprimer </button>
                                    </form>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                        <tfoot>
                            <tr>

                            </tr>
                        </tfoot>
                    </table>

                </div>
            </div>
        </div>

    </div>
</section>


<div class="modal fade" id="addCategorie" tabindex="-1">
    <div class="modal-dialog modal-dialog">
      <div class="modal-content">
        <div class="card">
            <div class="modal-header">
                <div class="modal-title">
                    <h5> Catégorie</h5>

                </div>
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
        <div class="modal-body">
            <form class="row g-3 p-" method="POST" action="<?php echo e(route('materiel.categorie.store')); ?>">
                <?php echo csrf_field(); ?>
                <div>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class=""><?php echo e($message); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-12 form-floating">
                  <input type="text" class="form-control" name="libelle" placeholder="libelle">
                  <label for="libelle"  class="form-label">Libelle</label>
                </div>

                <div class="">
                    <button type="submit" class="btn btn-success float-end">Valider</button>
                </div>
              </form><!-- End No Labels Form -->
        </div>

      </div>
    </div>
  </div><!-- End Vertically centered Modal-->

</div>
</section>
<?php if(Session::has('message')): ?>

<script>
toastr.success("<?php echo Session::get('message'); ?>");
</script>

<?php endif; ?>

<?php if($errors->all()): ?>

<script>
toastr.error("Une erreur c'est produite");
</script>

<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appImmo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u408137398/domains/jobs-conseil.tech/public_html/jobsgestion/resources/views/immobilisation/categorie/index.blade.php ENDPATH**/ ?>