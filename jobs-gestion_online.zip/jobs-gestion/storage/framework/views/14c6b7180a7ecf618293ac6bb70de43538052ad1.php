

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('marchandise.categorie.index')); ?>">

          <span>Catégories</span>
        </a>
      </li><!-- End F.A.Q Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('marchandise.index')); ?>">

          <span>Marchandises</span>
        </a>
      </li><!-- End Profile Page Nav -->

      

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('marchandise.inventaire.index')); ?>">

          <span>Inventaires</span>
        </a>
      </li><!-- End Contact Page Nav -->

    </ul>

  </aside><!-- End Sidebar-->
<?php /**PATH C:\Users\WILLNER\Desktop\projet_jobs\27jan\jobs-gestion6.8\resources\views/layouts/navbarMarchandise.blade.php ENDPATH**/ ?>