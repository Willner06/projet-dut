<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo e(asset('template/img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('template/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('template/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/quill/quill.snow.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/quill/quill.bubble.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/simple-datatables/style.css')); ?>" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('template/css/style.css')); ?>" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<style>
    body{
        background-repeat: no-repeat;
        background-size: 100% 104%;
        background-image: url(<?php echo e(asset('img-jb-gestion/fond.png')); ?>);

    }
</style>
<body>


    <main class=" m-4 p-2 row bg-prymary" style="widows: 100%">
        <div class=" col-sm-5">
            <img class="mx-5 py-2" src="<?php echo e(asset('img-jb-gestion/Logo_job_gestion.png')); ?>" alt="Logo JOBS CONSEIL" width="50%">

        </div>
        <div class=" col-sm-7 row d-inline">
          <h5>Veuiller sélectionner un module</h5>
            <a href="<?php echo e(route('caisse.home')); ?>"><img class="col-sm-5 m-" src="<?php echo e(asset('img-jb-gestion/caisse.png')); ?>" alt=""></a>
            <a href=""><img class="col-sm-5 m-" src="<?php echo e(asset('img-jb-gestion/immo.png')); ?>" alt=""></a>
            <a href=""><img class="col-sm-5 m-" src="<?php echo e(asset('img-jb-gestion/tiers.png')); ?>" alt=""></a>
            <a href=""><img class="col-sm-5 m-" src="<?php echo e(asset('img-jb-gestion/marchandise.png')); ?>" alt=""></a>
        </div>
    </main>


  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('template/vendor/apexcharts/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/chart.js/chart.umd.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/echarts/echarts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/quill/quill.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/simple-datatables/simple-datatables.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/tinymce/tinymce.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/php-email-form/validate.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('template/js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion5.2\resources\views/home.blade.php ENDPATH**/ ?>