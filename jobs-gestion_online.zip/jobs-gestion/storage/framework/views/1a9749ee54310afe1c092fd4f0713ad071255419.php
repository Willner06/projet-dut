<?php $__env->startSection('content'); ?>

<div class="card">


<?php if(Route::is('caisse.decaissement.carburant')): ?>
<section>
    <div class="  mt-4">



<div class="">
    <div class="">
        <h5 class="float-end m-3">
            <div class="search-bar header">
                <form class="search-form d-flex align-items-center" method="POST" action="<?php echo e(route('caisse.decaissement.searchCarburant')); ?>">
                    <?php echo csrf_field(); ?>
                  <input type="month" name="query" placeholder="Search" title="Entrez le mois recherché" required>
                  <button type="submit" title="Search"><i class="bi bi-search"></i></button>
                </form>
              </div><!-- End Search Bar -->
        </h5>
      <h5 class="card-title">Frais de carburant <?php echo e(date("M Y")); ?></h5>
        <br><br>
      <!-- Default Tabs -->
      



            <div class="table-responsive">
                <table class="table datatable table-bordered">
                    <thead class="text-center">
                        <tr class="text-white text-center" style="background-color: #254b7d">
                            <th>Dates</th>
                            <th>Montants</th>
                            <th>Dénomination</th>
                            <th>Règlement</th>
                            <th>Mois</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $carburants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carburant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($carburant->created_at->format('d/M/y')); ?></td>
                            <td class="text-"><?php echo e(number_format($carburant->somme,0,'.',' ').$monaie); ?></td>
                                <td><?php echo e($carburant->motif->reglement->denomination); ?></td>
                            <?php if($carburant->motif->reglement->reglement == "1"): ?>
                                <td><img src="<?php echo e(asset('icons/yes.png')); ?>" alt=""></td>
                            <?php else: ?>
                                <td><img src="<?php echo e(asset('icons/no.png')); ?>" alt=""></td>
                            <?php endif; ?>
                            <td><?php echo e(date("M Y")); ?></td>
                            <td>
                                <?php if($carburant->motif->reglement->denomination == null): ?>
                                <a href="" class="badge text-bg-warning" data-bs-toggle="modal" data-bs-target="#control-<?php echo e($carburant->motif->id); ?>">
                                    Régler
                                </a>
                                <?php else: ?>
                               
                                <?php endif; ?>
                            </td>
                        </tr>
                        <div class="modal fade" id="control-<?php echo e($carburant->motif->id); ?>" tabindex="-1">
                            <div class="modal-dialog modal-dialog-centered">
                              <div class="modal-content">
                                <div class="card">
                                    <div class="modal-header">
                                        <div class="modal-title">
                                            <h5> Règlement -<?php echo e($carburant->motif->id); ?></h5>

                                        </div>
                                        <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                <div class="modal-body">
                                    <form class="row g-3 p-" method="POST" action="<?php echo e(route('caisse.reglement.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class=""><?php echo e($message); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="col-md-12 form-floating mt-4">
                                          <input type="text" name="denomination" class="form-control" placeholder="Dénomination" required>
                                          <label for="denomination"  class="form-label">Dénomination</label>
                                        </div>
                                        

                                        <div class="">
                                            <button type="submit" class="btn btn-success float-end" name="validation" value="<?php echo e($carburant->motif->reglement->id); ?>">Valider</button>
                                          </div>
                                      </form><!-- End No Labels Form -->
                                </div>

                              </div>
                            </div>
                          </div><!-- End Vertically centered Modal-->

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>

                    </tfoot>
                </table>
                <table class="table w-50">
                    <tbody>
                        <tr class="bg-primary text-white ">
                            <td class="text-end">Total</td>
                            <td class="text-center"><?php echo e(number_format($totalMoisEnCour,0,'.',' ').$monaie); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
      </div>

</section>


<?php else: ?>


<section>
    <div class="card">
        <div>
            <h5 class="w-25 m-3 float-end">
                <div class="search-bar header">
                    <form class="search-form d-flex align-items-center" method="POST" action="<?php echo e(route('caisse.decaissement.searchCarburant')); ?>">
                        <?php echo csrf_field(); ?>
                      <input type="month" name="query" placeholder="Search" title="Entrez le mois recherché" max="<?php echo e(date("Y-m")); ?>" required>
                      <button type="submit" title="Search"><i class="bi bi-search"></i></button>
                    </form>
                  </div><!-- End Search Bar -->
            </h5>
          <h5 class="card-title m-5">Frais de carburant <?php echo e($mois." ".$annee); ?></h5>
        </div>

        <div class="card table-responsive">
            <table class="table datatable table-bordered">
                <thead class="text-center">
                    <tr class="text-white text-center" style="background-color: #254b7d">
                        <th>Dates</th>
                        <th>Montants</th>
                        <th>Dénomination</th>
                        <th>Règlement</th>
                        <th>Mois</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $carburants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carburant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td><?php echo e($carburant->created_at->format('d/M/y')); ?></td>
                        <td class="text-"><?php echo e(number_format($carburant->somme,0,'.',' ').$monaie); ?></td>
                            <td><?php echo e($carburant->motif->reglement->denomination); ?></td>
                        <?php if($carburant->motif->reglement->reglement == "1"): ?>
                            <td><img src="<?php echo e(asset('icons/yes.png')); ?>" alt=""></td>
                        <?php else: ?>
                            <td><img src="<?php echo e(asset('icons/no.png')); ?>" alt=""></td>
                        <?php endif; ?>
                        <td><?php echo e(date("M Y")); ?></td>
                        <td>
                            <?php if($carburant->motif->reglement->denomination == null): ?>
                            <a href="" class="badge text-bg-warning" data-bs-toggle="modal" data-bs-target="#control-<?php echo e($carburant->motif->id); ?>">
                                Régler
                            </a>
                            <?php else: ?>
                           a
                            <?php endif; ?>
                        </td>
                    </tr>
                    <div class="modal fade" id="control-<?php echo e($carburant->motif->id); ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                          <div class="modal-content">
                            <div class="card">
                                <div class="modal-header">
                                    <div class="modal-title">
                                        <h5> Règlement -<?php echo e($carburant->motif->id); ?></h5>

                                    </div>
                                    <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                            <div class="modal-body">
                                <form class="row g-3 p-" method="POST" action="<?php echo e(route('caisse.reglement.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class=""><?php echo e($message); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="col-md-12 form-floating mt-4">
                                      <input type="text" name="denomination" class="form-control" placeholder="Dénomination" required>
                                      <label for="denomination"  class="form-label">Dénomination</label>
                                    </div>
                                    

                                    <div class="">
                                        <button type="submit" class="btn btn-success float-end" name="validation" value="<?php echo e($carburant->motif->reglement->id); ?>">Valider</button>
                                      </div>
                                  </form><!-- End No Labels Form -->
                            </div>

                          </div>
                        </div>
                      </div><!-- End Vertically centered Modal-->

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>

                </tfoot>
            </table>
            <table class="table w-50 ">
                <tbody>
                    <tr class="bg-primary text-white ">
                        <td class="text-end">Total</td>
                        <td class="text-center"><?php echo e(number_format($totalMoisEnCour,0,'.',' ').$monaie); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>

<?php endif; ?>



</div>



    <style>
        .switch {
 position: relative;
 display: inline-block;
 width: 120px;
 height: 34px;
}

.switch input {
 display: none;
}

.slider {
 position: absolute;
 cursor: pointer;
 top: 0;
 left: 0;
 right: 0;
 bottom: 0;
 background-color: #3C3C3C;
 -webkit-transition: .4s;
 transition: .4s;
 border-radius: 34px;
}

.slider:before {
 position: absolute;
 content: "";
 height: 26px;
 width: 26px;
 left: 4px;
 bottom: 4px;
 background-color: white;
 -webkit-transition: .4s;
 transition: .4s;
 border-radius: 50%;
}

input:checked + .slider {
 background-color: #0E6EB8;
}

input:focus + .slider {
 box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
 -webkit-transform: translateX(26px);
 -ms-transform: translateX(26px);
 transform: translateX(85px);
}

/*------ ADDED CSS ---------*/
.slider:after {
 content: 'Pas effectué';
 color: white;
 display: block;
 position: absolute;
 transform: translate(-50%,-50%);
 top: 50%;
 left: 50%;
 font-size: 10px;
 font-family: Verdana, sans-serif;
}

input:checked + .slider:after {
 content: 'Effectué';
}

/*--------- END --------*/
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobs-gestion9.7\resources\views/caisse/ficheCarburant.blade.php ENDPATH**/ ?>