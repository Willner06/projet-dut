<?php $__env->startSection('content'); ?>

<?php if(Route::is('caisse.decaissement.communication')): ?>
<section>
    <div class=" card m-3">
        <div>
            <h5 class="float-end m-3">
                <div class="search-bar header">
                    <form class="search-form d-flex align-items-center" method="POST" action="<?php echo e(route('caisse.decaissement.searchCommunication')); ?>">
                        <?php echo csrf_field(); ?>
                      <input type="month" name="query" placeholder="Search" title="Entrez le mois recherché" required>
                      <button type="submit" title="Search"><i class="bi bi-search"></i></button>
                    </form>
                  </div><!-- End Search Bar -->
            </h5>
          <h5 class="card-title m-2">Frais de Communication</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead >
                    <tr class="text-center m-3 text-white" style="background-color: #254b7d">
                        <th colspan="4">Frais de communication <span class="text-primary text-danger"><?php echo e(date("M Y")); ?></span></th>
                    </tr>
                    <tr class="text-center">
                        <th>Date</th>
                        <th>N° Pièce</th>
                        <th>Motif</th>
                        <th>Montant</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $communications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $communication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td><?php echo e($communication->created_at->format('d/M/y')); ?></td>
                        <td><?php echo e($communication->num_piece); ?></td>
                        <td><?php echo e($communication->motif->description); ?></td>
                        <td><?php echo e(number_format($communication->somme,0,'.',' ').$monaie); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr  class="text-center">
                        <td class=" bg-primary text-white" colspan="3">
                            Total frais de communication mois antérieur <?php echo e(date("F Y", strtotime('-1 month'))); ?>

                        </td>
                        <td>
                            <?php echo e(number_format($totalMoisAnterieur,0,'.',' '.'').$monaie); ?>

                        </td>
                        <td>
                            Variation
                        </td>
                    </tr>
                    <tr class="bg-primary text-center">
                        <td colspan="3" class=" text-white" >
                            Total frais de communication <?php echo e(date("M Y")); ?>

                        </td>
                        <td class=" text-white">
                            <?php echo e(number_format($totalMoisEnCour,0,'.',' '.'').$monaie); ?>

                        </td>
                        <td class=" text-white">
                            <?php echo e(number_format($difference,0,'.',' ').''.$monaie); ?>

                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</section>

<?php else: ?>

<section>
    <div class=" card m-3">
        <div>
            <h5 class="w-25 m-3 float-end">
                <div class="search-bar header">
                    <form class="search-form d-flex align-items-center" method="POST" action="<?php echo e(route('caisse.decaissement.searchCommunication')); ?>">
                        <?php echo csrf_field(); ?>
                      <input type="month" name="query" placeholder="Search" title="Entrez le mois recherché" max="<?php echo e(date("Y-m")); ?>" required>
                      <button type="submit" title="Search"><i class="bi bi-search"></i></button>
                    </form>
                  </div><!-- End Search Bar -->
            </h5>
            <h5 class="card-title m-2">Frais de Communication</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead >
                    <tr class="text-center m-3 text-white" style="background-color: #254b7d">
                        <th colspan="4">Frais de communication <span class="text-primary text-danger"><?php echo e(date("M Y",$date)); ?></span></th>
                    </tr>
                    <tr class="text-center">
                        <th>Date</th>
                        <th>N° Pièce</th>
                        <th>Motif</th>
                        <th>Montant</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $communications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $communication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td><?php echo e($communication->created_at->format('d/M/y')); ?></td>
                        <td><?php echo e($communication->num_piece); ?></td>
                        <td><?php echo e($communication->motif->description); ?></td>
                        <td><?php echo e(number_format($communication->somme,0,'.',' ').$monaie); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr class="bg-primary text-center">
                        <td colspan="3" class=" text-white" >
                            Total
                        </td>
                        <td class=" text-white">
                            <?php echo e(number_format($totalMoisEnCour,0,'.',' '.'').$monaie); ?>

                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</section>

<?php endif; ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion5.1_test\resources\views/caisse/ficheCommunication.blade.php ENDPATH**/ ?>