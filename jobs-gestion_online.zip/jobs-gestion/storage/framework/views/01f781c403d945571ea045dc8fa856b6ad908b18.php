<?php $__env->startSection('content'); ?>
    <div>
        <div class="pagetitle">
            <div class="">
                <h1><?php echo e($categorie->libelle); ?></h1>
                <div class="card float-end">
                    <button class="badge text-bg-success m-3" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalToggle-<?php echo e($categorie->id); ?>"> <i class="bi bi-plus-lg"></i> Produit </button>
                </div>
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </nav>
            <br><br>
            </div>

        </div><!-- End Page Title -->

        <div class="row">
            
                <div class="table-responsive card">
                    <table class="datatable">
                        <thead>
                            <tr class="text-center">
                                <th>Reference</th>
                                <th>Désignation</th>
                                <th>Catégorie</th>
                                <th>Prix unitaire</th>
                                <th>Quantité</th>
                                <th>Valeur du stock</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $categorie->marchandises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marchandise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($marchandise->reference); ?></td>
                                    <td><?php echo e($marchandise->designation); ?></td>
                                    <td><?php echo e($marchandise->categorie->libelle); ?></td>
                                    <td><?php echo e($marchandise->prix_unitaire); ?> Fcfa</td>
                                    <td><?php echo e(optional($marchandise->stock)->stock*1); ?></td>
                                    <td><?php echo e($marchandise->prix_unitaire * optional($marchandise->stock)->stock); ?> Fcfa</td>
                                    <td>
                                        <a href="<?php echo e(route('marchandise.show', $marchandise->id)); ?>" class=" text-bg-warning badge">Voir</a>
                                        <a href="<?php echo e(route('marchandise.delete',$marchandise->id)); ?>" class="card-link text-bg-danger badge" onclick="confirm('Êtes vous sûr de vouloir supprimer?')">Supprimer</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                        <tfoot>
                            <tr>
                                <th>Date</th>
                                <th>Reference</th>
                                <th>Fournisseur</th>
                                <th>Désignation</th>
                                <th>Catégorie</th>
                                <th>Prix unitaire</th>
                                <th>Quantité</th>
                                <th>Valeur du stock</th>
                                <th>Motif</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
        </div>
    </div>



    <div class="modal fade" id="exampleModalToggle-<?php echo e($categorie->id); ?>" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
                <form class="row g-3 needs-validation" novalidate method="post" action="<?php echo e(route('marchandise.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-12">
                        <label for="categorie" class="form-label">Catégorie</label>
                        <select class="form-select" id="categorie" name="categorie_id" required>
                          <option selected value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->libelle); ?></option>
                        </select>
                    </div>
                    <div class="col-md-12">
                      <label for="reference" class="form-label">Reference</label>
                      <input type="text" class="form-control" id="reference" name="reference" required>
                    </div>
                    <div class="col-md-12">
                      <label for="designation" class="form-label">Désignation</label>
                      <input type="text" class="form-control" id="designation" name="designation" required>
                    </div>
                    <div class="col-md-12">
                        <label for="prix_unitaire" class="form-label">Prix unitaire</label>
                        <input type="number" class="form-control" id="prix_unitaire" name="prix_unitaire" required>
                    </div>
                    <div class="col-12">
                      <button class="btn btn-success float-end" type="submit">Valider</button>
                    </div>
                  </form>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2" tabindex="-1">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appMarchandise', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WILLNER\Desktop\projet_jobs\27jan\jobs-gestion8.7\resources\views/marchandise/categories/show.blade.php ENDPATH**/ ?>