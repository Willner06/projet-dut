<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-">
        <div class="card row">
            <div></div>
            <div>

            </div>
        </div>
    </div>

    <div class="col-sm-12"><div class="">
        <div class="card-body">

            <div>
                <h5 class="card-title d-inline">Liste des decaissements</h5>
            </div>

            <div class="float-end card" >
              <button class="btn btn-success float-end m-2" data-bs-toggle="modal" data-bs-target="#adddecaissement">Ajouter</button>
            </div><br><br><br>
        </div>

          <!-- Table with stripped rows -->
          <div class="card">
            <div style="box-shadow: 1px 1px 10px black;" class="table-responsive">
                <table class="table table-striped datatable text-center" >
                    <thead>
                      <tr>
                        <th class="text-center" scope="col">#</th>
                        <th class="text-center" scope="col">Caissier</th>
                        <th class="text-center" scope="col">Date</th>
                        <th class="text-center" scope="col">Deumandeur</th>
                        <th class="text-center" scope="col">Autorisé par</th>
                        <th class="text-center" scope="col">Somme</th>
                        <th class="text-center" scope="col">Motif</th>
                        <th class="text-center" scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $decaissements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decaissement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th ><?php echo e($decaissement->num_piece); ?></th>
                            <td><?php echo e($decaissement->created_at->format('d/m/Y')); ?></td>
                            <td><?php echo e($decaissement->user->name); ?></td>
                            <td><?php echo e($decaissement->demandeur); ?></td>
                            <td><?php echo e($decaissement->autorisePar); ?></td>
                            <td><?php echo e(number_format($decaissement->somme,0,'.',' ').$monaie); ?></td>
                            <td>
                            <?php echo e($decaissement->motif->libelle); ?>

                            </td>
                            <td>
                                <a href="<?php echo e(route('caisse.decaissement.export',$decaissement->id)); ?>" target="_blank" class="badge m-3 text-bg-warning">Imprimer</a>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
              </div>
          </div>
          <!-- End Table with stripped rows -->
        </div>
      </div>
    </div>


<div class="modal fade" id="adddecaissement" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="card">
            <div class="modal-header">
                <div class="modal-title">
                    <h5> Décaissement</h5>

                </div>
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
        <div class="modal-body">
            <form class="row g-3 p-" method="POST" action="<?php echo e(route('caisse.decaissement.store')); ?>">
                <?php echo csrf_field(); ?>
                <div>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class=""><?php echo e($message); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-12">
                  <label for="demandeur" id="demandeur"  class="form-label">Nom du demandeur</label>
                  <input type="text" name="demandeur" class="form-control" equired>
                </div>
                <div class="col-md-6">
                  <label for="code" class="form-label">Code</label>
                    <select class="form-select" id="code" name="code" id="code">
                        <option value="" disabled>----Choisir le code----</option>
                        <option value="001"> 001</option>
                        <option value="002">002</option>
                        <option value="003">003</option>
                        <option value="004">004</option>
                    </select>
                </div>
                <div class="col-md-6">
                  <label for="somme" class="form-label">Somme</label>
                  <input type="number" id="somme" name="somme" class="form-control" placeholder="Somme" required>
                  
                </div>
                <div class="col-md-12">
                  <label for="autorise_par"  class="form-label">Autorisé par</label>
                  <input type="text" id="autorise_par" name="autorise_par" class="form-control"  required>
                </div>
                <div class="col-md-12" >

                    <label class="form-label" for="">Motif(s)</label>
                    <div class="form-control p-3"  style="overflow: auto; height:130px">
                        <input type="radio" name="motif" class="form-check-input " id="1" value="prospection">
                        <label for="1" class="form-label">Prospection</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="survey" id="2">
                        <label for="2" class="form-label">Survey</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="intervention" id="3">
                        <label for="3" class="form-label">Intervention</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="procedure administrative" id="4">
                        <label for="4" class="form-label">Procedure administrative</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="livraison sur vente" id="5">
                        <label for="5" class="form-label">Livraison sur vente</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="carburant" id="6">
                        <label for="6" class="form-label">Carburant</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="communication" id="7">
                        <label for="7" class="form-label">Communication</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="autre" id="autre">
                        <label for="autre" class="form-label">autre</label>
                    </div>

                </div>
                <div class="col-md-12">
                  <label for="description" class="form-label">Décrire en quelques ligne le motif</label>
                    <textarea name="description" id="description" cols="30" rows="10" class="form-control" style="height: 200px" required></textarea>
                  </div>
                <div class="">
                    <button type="submit" class="btn btn-success float-end">Valider</button>
                  </div>
              </form><!-- End No Labels Form -->
        </div>

      </div>
    </div>
  </div><!-- End Vertically centered Modal-->

</div>
</div>
</div>

<?php if(Session::has('message')): ?>

<script>
    toastr.success("<?php echo Session::get('message'); ?>");
</script>

<?php endif; ?>

<?php if($errors->all()): ?>

<script>
    toastr.error("Une erreur c'est produite");
</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WILLNER\Desktop\projet_jobs\27jan\jobs-gestion7.5\resources\views/caisse/indexDecaissement.blade.php ENDPATH**/ ?>