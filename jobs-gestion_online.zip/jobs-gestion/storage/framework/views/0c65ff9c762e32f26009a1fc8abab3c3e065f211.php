<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WILLNER\Desktop\projet_jobs\27jan\jobs-gestion2.3-php\resources\views/caisse/home.blade.php ENDPATH**/ ?>