
<?php $__env->startSection('content'); ?>

<div>
    <div class="pagetitle">
        <div class="">
            <h1><?php echo e($user->nom); ?></h1>
            <div class="card float-end">
                
            </div>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        <br><br>
        </div>

    </div><!-- End Page Title -->

    <div class="row">
        <div class="table-responsive card">
            <table class="datatable">
                <thead>
                    <tr>
                        
                        <th>Nom(s)</th>
                        <th>Prénom(s)</th>
                        <th>Email</th>
                        <th>Fonction</th>
                        <th>Action</th>
                        
                    </tr>
                </thead>
                <tbody>
                    
                    <tr>
                        
                        <td><?php echo e($user->nom); ?></td>
                        <td><?php echo e($user->prenom); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->fonction); ?></td>
                        <td>
                            <a href="<?php echo e(route('user.show', $user->id)); ?>" class=" text-bg-warning badge">Voir</a>
                            <?php if($user->email != Auth::user()->email): ?>
                            <form class="d-inline" action="<?php echo e(route('user.destroy',$user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="text-bg-danger badge" onclick="return confirm('Êtes vous sûr de vouloir supprimer?')">Supprimer</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                </tbody>
                <tfoot>
                    <tr>

                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

</div>



<?php if(Session::has('message')): ?>

<script>
    toastr.success("<?php echo Session::get('message'); ?>");
</script>

<?php endif; ?>


<?php if($errors->all()): ?>

<script>
    toastr.error("Une erreur c'est produite");
</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appTiers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobs-gestion9.6\resources\views/user/show.blade.php ENDPATH**/ ?>