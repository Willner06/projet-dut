<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <link href="<?php echo e(asset('img-jb-gestion/Logo_job_gestion.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('img-jb-gestion/Logo_job_gestion.png')); ?>" rel="apple-touch-icon">

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>JOBS GESTION</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('template/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/quill/quill.snow.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/quill/quill.bubble.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/simple-datatables/style.css')); ?>" rel="stylesheet">

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


  <!-- CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/css/toastr.css" rel="stylesheet" />

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('template/css/style.css')); ?>" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>


<body>

  <!-- ======= Header ======= -->

  
  
  

  <main id="main" class="main">
    
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  <!-- Vendor JS Files -->
  <script src="<?php echo e(asset('template/vendor/apexcharts/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/chart.js/chart.umd.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/echarts/echarts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/quill/quill.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/simple-datatables/simple-datatables.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/tinymce/tinymce.min.js')); ?>"></script>
  <script src="<?php echo e(asset('template/vendor/php-email-form/validate.js')); ?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo e(asset('template/js/main.js')); ?>"></script>
  <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>


<!-- JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>


</body>

</html>

<?php echo $__env->make('layouts.navbarMarchandise', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.headerMarchandise', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion6.2\resources\views/layouts/appMarchandise.blade.php ENDPATH**/ ?>