<?php $__env->startSection('content'); ?>

    <section>
      <div class="row">
        <div class="col-sm-4">
          <div class="card">

            

            <div class="card-body">
              <h5 class="card-title">Sales <span>| Today</span></h5>

              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-cart"></i>
                </div>
                <div class="ps-3">
                  <h6>145</h6>
                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>

                </div>
              </div>
            </div>
          </div>
        </div>



        <div class="col-sm-4">
          <div class="card">
            

            <div class="card-body">
              <h5 class="card-title">Sales <span>| Today</span></h5>

              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-cart"></i>
                </div>
                <div class="ps-3">
                  <h6>145</h6>
                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>

                </div>
              </div>
            </div>
          </div>
        </div>



        <div class="col-sm-4">
          <div class="card">
            

            <div class="card-body">
              <h5 class="card-title">Sales <span>| Today</span></h5>

              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-cart"></i>
                </div>
                <div class="ps-3">
                  <h6>145</h6>
                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>



        <div class="row">
          <div class="col-lg-6">
            <div class="card">
              <canvas id="parAnnee"></canvas>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="card">
              <canvas id="parMois" class="datatable"></canvas>
            </div>
          </div>
        </div>

    </section>



    <script>
        const parannee = document.getElementById('parAnnee');

        new Chart(parannee, {
          type: 'bar',
          data: {
            labels: [<?php $__currentLoopData = $decaissements_annee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($dec->annee); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],

            datasets: [{
              label: 'Décaissment',
              data: [<?php $__currentLoopData = $decaissements_annee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decaissements): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($decaissements->total_decaissements); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],
              borderWidth: 1,
              borderColor: '#36A2EB',
                backgroundColor: 'yellow',
            },
            {
              label: 'Encaissement',
              data: [<?php $__currentLoopData = $encaissements_annee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encaissements): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($encaissements->total_encaissements); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],
              borderWidth: 1,
              borderColor: '#36A2EB',
                backgroundColor: 'green',
            }
        ]
          },
          options: {
            scales: {
              y: {
                beginAtZero: true
              }
            }
          }
        });



        const parmois = document.getElementById('parMois');

        new Chart(parmois, {
          type: 'line',
          data: {
            labels: [<?php $__currentLoopData = $decaissements_mois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decaissements): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($decaissements->mois."-".$decaissements->annee); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],

            datasets: [{
              label: 'Décaissment',
              data: [<?php $__currentLoopData = $decaissements_mois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decaissements): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                '<?php echo e($decaissements->total); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],
              borderWidth: 1,
              borderColor: '#36A2EB',
                backgroundColor: 'yellow',
            }
        ]
          },
          options: {
            scales: {
              y: {
                beginAtZero: true
              }
            }
          }
        });
      </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion7.2\resources\views/caisse/dashboard.blade.php ENDPATH**/ ?>