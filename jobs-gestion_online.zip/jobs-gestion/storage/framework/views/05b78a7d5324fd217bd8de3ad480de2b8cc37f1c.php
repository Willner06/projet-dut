<?php $__env->startSection('content'); ?>
    <section>
        <div class="float-end  w-25">
            <div class="search-bar header">
                <form class="search-form d-flex align-items-center" method="POST" action="<?php echo e(route('caisse.decaissement.searchCarburant')); ?>">
                    <?php echo csrf_field(); ?>
                  <input type="month" name="query" placeholder="Search" title="Entrez le mois recherché" required>
                  <button type="submit" title="Search"><i class="bi bi-search"></i></button>
                </form>
              </div><!-- End Search Bar -->

            </div><br><br>
        <div class="card mt-5">
            <div>
                
              <h5 class="card-title m-2">Fiche de clôture de caisse</h5>
            </div>
            <div class="table-responsive m-3">
                <table class="table  text-center datatable">
                    <thead>
                        <tr class="text-center text-white" style="background-color: #254b7d">
                            <th>Date</th>
                            <th>Agent caisse</th>
                            <th>Contrôleur</th>
                            <th>Date de contrôle</th>
                            <th>Solde théorique</th>
                            <th>Solde réel</th>
                            <th>Ecart</th>
                            <th>Commentaire</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $clotures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cloture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                            <td><?php echo e($cloture->created_at->format("d-m-Y")); ?></td>
                            <td><?php echo e($cloture->agent_caisse); ?></td>
                            <td><?php echo e($cloture->controlleur); ?></td>
                            <td><?php echo e($cloture->date_controle); ?></td>
                            <td><?php echo e($cloture->compte->solde); ?></td>
                            <td><?php echo e($cloture->solde_reel); ?></td>
                            <?php if(($cloture->solde_reel-$cloture->compte->solde)>0): ?>
                                <td class="text-warning"><?php echo e($cloture->solde_reel-$cloture->compte->solde); ?></td>
                            <?php endif; ?>
                            <?php if(($cloture->solde_reel-$cloture->compte->solde)==0): ?>
                                <td class="text-success"><?php echo e($cloture->solde_reel-$cloture->compte->solde); ?></td>
                            <?php endif; ?>
                            <?php if(($cloture->solde_reel-$cloture->compte->solde)<0): ?>
                                <td class="text-danger"><?php echo e($cloture->solde_reel-$cloture->compte->solde); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($cloture->commentaire); ?></td>
                            <td>
                                <?php if($cloture->status==false): ?>
                                <a href="#" class="badge bg-success" data-bs-toggle="modal" data-bs-target="#control-<?php echo e($cloture->id); ?>">Contrôller</a>
                                <?php else: ?>
                                <a href="#" class="badge bg-warning" data-bs-toggle="modal" data-bs-target="#control-<?php echo e($cloture->id); ?>">Modifier</a>
                                <?php endif; ?>
                            </td>
                        </tr>




                    <div class="modal fade" id="control-<?php echo e($cloture->id); ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="card">
                                <div class="modal-header">
                                    <div class="modal-title">
                                        <h5>Contrôle</h5>
                                    </div>
                                    <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                            <div class="modal-body">
                                <form class="row g-3 p-" method="POST" action="<?php echo e(route('cloture.controle',$cloture->id)); ?>">
                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>
                                    <div>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class=""><?php echo e($message); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="col-md-12 mt-4 mb-4">
                                        <label for="solde_reel" class="form-label">Solde Réel</label>
                                        <input type="number" name="solde_reel" class="form-control" placeholder="<?php echo e($cloture->solde_reel); ?>">

                                    </div>
                                    <div class="col-md-12 mb-4">

                                        <label for="commetaire" class="form-label">Commentaire</label>
                                        <textarea name="commentaire" id="commetaire" cols="30" rows="10" class="form-control" placeholder="<?php echo e($cloture->commentaire); ?>" style="height: 200px"></textarea>
                                    </div>
                                    <div class="">
                                        <button type="submit" class="btn btn-success float-end">Valider</button>
                                    </div>
                                </form><!-- End No Labels Form -->
                            </div>

                        </div>
                        </div>
                    </div><!-- End Vertically centered Modal-->

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tr class="text-center ">
                        <td class="bg-primary text-white" colspan="4">
                            ARRETER DE LA CAISSE AU <?php echo e(date("t-m-Y", strtotime(date("d-M-Y")))); ?>

                        </td>
                        
                        <td class="bg-primary text-white"><?php echo e($monaie); ?></td>
                        <td class="bg-success-subtle"><?php echo e($monaie); ?></td>
                        <td></td>
                    </tr>

                    <tfoot>

                    </tfoot>
                </table>
                <table class="table">
                    <th>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                    </th>
                    <tbody>
                        <tr class="text-center ">
                            <td class="bg-primary text-white" colspan="4">
                                ARRETER DE LA CAISSE AU <?php echo e(date("t-m-Y", strtotime(date("d-M-Y")))); ?>

                            </td>
                            
                            <td class="bg-primary text-white"><?php echo e($monaie); ?></td>
                            <td class="bg-success-subtle"><?php echo e($monaie); ?></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>




</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion7.2\resources\views/caisse/clotureCaisse.blade.php ENDPATH**/ ?>