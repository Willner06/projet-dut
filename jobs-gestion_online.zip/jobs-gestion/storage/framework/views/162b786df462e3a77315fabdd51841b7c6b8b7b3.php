<?php $__env->startSection('content'); ?>

    <section>
        <div class="pagetitle">
            <div class="">
                <h1>Catégories</h1>
                <div class="card float-end">
                    <button class="badge text-bg-success m-3" type="button" data-bs-toggle="modal" data-bs-target="#addmarchandise"><i class="bi bi-plus-lg"> Catégorie </i></button>
                </div>
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active">Catégories</li>
                    </ol>
                </nav>
            <br><br>
            </div>

        </div><!-- End Page Title -->

        <div class="row">
            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3">
                    <div class="card">
                        <div class="card-body">
                            <img class="float-end m-3" src="<?php echo e(asset('icons/package.png')); ?>" alt="">
                          <h4 class=" fs-3 card-title"><?php echo e($categorie->libelle); ?></h4>
                          <h6 class="card-subtitle mb-2 text-muted"></h6>
                          <h3 class="text-center">

                            <?php echo e($categorie->marchandises->count()); ?> <br> type de marchandise
                          </h3>

                          <div class="float-end">
                            <a href="#" class="card-link text-bg-danger badge">Supprimer</a>
                            <a href="<?php echo e(route('marchandise.categorie.show', $categorie->id)); ?>" class=" text-bg-warning badge">Voir</a>
                          </div>
                        </div>
                    </div><!-- End Card with titles, buttons, and links -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="table-responsive ">
                    

                </div>
            </div>
        </div>



        <div class="modal fade" id="addmarchandise" tabindex="-1">
            <div class="modal-dialog modal-dialog">
              <div class="modal-content">
                <div class="card">
                    <div class="modal-header">
                        <div class="modal-title">
                            <h5> Catégorie</h5>

                        </div>
                        <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                <div class="modal-body">
                    <form class="row g-3 p-" method="POST" action="<?php echo e(route('marchandise.categorie.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class=""><?php echo e($message); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="col-md-12 form-floating">
                          <input type="text" class="form-control" name="libelle" placeholder="libelle">
                          <label for="libelle"  class="form-label">Libelle</label>
                        </div>

                        <div class="">
                            <button type="submit" class="btn btn-success float-end">Valider</button>
                        </div>
                      </form><!-- End No Labels Form -->
                </div>

              </div>
            </div>
          </div><!-- End Vertically centered Modal-->

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appMarchandise', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion6.9\resources\views/marchandise/categories/index.blade.php ENDPATH**/ ?>