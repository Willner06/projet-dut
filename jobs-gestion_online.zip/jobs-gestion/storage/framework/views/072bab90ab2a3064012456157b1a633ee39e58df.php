<?php $__env->startSection('content'); ?>

<div class="section">
    <div class="pagetitle">
        <div class="">
            <h1>Dashboard</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        <br><br>
        </div>

    </div><!-- End Page Title -->

    <div class="row">
        <div class="col-sm-4">
            <div class="card">

              

              <div class="card-body">
                <h5 class="card-title">Chiffre d'affaire total</h5>



                  <div class="ps-3 text-center">
                    <h6 class="fs-4"><?php echo e(number_format($caTotalClient,0,'.',' ')." ".$monaie); ?></h6>

                  </div>
              </div>
            </div>
          </div>



          <div class="col-sm-4">
            <div class="card">

              

              <div class="card-body">
                <h5 class="card-title">Achat total</h5>

                  <div class="ps-3 text-center">
                    <h6 class="fs-4"><?php echo e(number_format($totalAcha,0,'.',' ')." ".$monaie); ?></h6>

                  </div>
              </div>
            </div>
          </div>




          <div class="col-sm-4">
            <div class="card">

              

              <div class="card-body">
                <h5 class="card-title">Somme total des autres tiers</h5>



                  <div class="ps-3 text-center">
                    <h6 class="fs-4"><?php echo e(number_format($caTotalAutre,0,'.',' ')." ".$monaie); ?></h6>

                  </div>
              </div>
            </div>
          </div>


    </div>

    <div class="row">


        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Chiffre d'affaire mensuel des clients</h5>

              <!-- Polar Area Chart -->
              <div id="parMois" style="max-height: 400px;"></div>
              

                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                    new ApexCharts(document.querySelector("#parMois"), {
                        series: [{
                        name: "Desktops",
                        data: [
                            <?php $__currentLoopData = $caMensuel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camois): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        '<?php echo e($camois->ca); ?>',
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ]
                        }],
                        chart: {
                        // height: 350,
                        type: 'line',
                        zoom: {
                            enabled: false
                        }
                        },
                        dataLabels: {
                        enabled: false
                        },
                        stroke: {
                        curve: 'straight'
                        },
                        grid: {
                        row: {
                            colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
                            opacity: 0.5
                        },
                        },
                        xaxis: {
                        categories: [
                            <?php $__currentLoopData = $caMensuel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camois): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        '<?php echo e($camois->mois."-".$camois->annee); ?>',
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ],
                        }
                    }).render();
                    });
                </script>
            </div>
          </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
            <div class="card-body">
                <h5 class="card-title">Chiffre d'affaire par client</h5>

                <!-- Polar Area Chart -->
                <div id="polarAreaChart" style="max-height: 500px;"></div>
                


                <script>
                document.addEventListener("DOMContentLoaded", () => {
                  new ApexCharts(document.querySelector("#polarAreaChart"), {
                    series: [ <?php $__currentLoopData = $caParClient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                '<?php echo e($client->ca); ?>',
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],
                    chart: {
                      type: 'polarArea',
                    //   height: 100,
                      toolbar: {
                        show: true
                      }
                    },
                    stroke: {
                      colors: ['#fff']
                    },
                    fill: {
                      opacity: 0.8
                    },
                    labels: [
                        <?php $__currentLoopData = $caParClient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                '<?php echo e($client->nom." ".$client->prenom." ".$client->ca."Fcfa"); ?>',
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ],
                  }).render();
                });
              </script>
                <!-- End Polar Area Chart -->

            </div>
            </div>
        </div>

        <div class="col-lg-6">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Montant recouvré et non recouvré des clients</h5>

              <!-- Doughnut Chart -->
              <div id="doughnutChart" style="max-height: 400px;"></div>


                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                      new ApexCharts(document.querySelector("#doughnutChart"), {
                        series: [<?php echo e($caTotalClient, $monaie); ?>, <?php echo e($montantNomRecouvre); ?>],
                        chart: {
                        //   height: 350,
                          type: 'donut',
                          toolbar: {
                            show: true
                          }
                        },
                        labels: [
                                        'Montant recouvré ',
                                        'Montant non recouvré '
                                      ],
                      }).render();
                    });
                  </script>
              <!-- End Doughnut CHart -->

            </div>
          </div>
        </div>





        <hr>



        <div class="col-lg-12">
            <div class="card">
              <div class="card-body" style="background-color: #ebebe8">
                <h5 class="card-title">Chiffre d'affaire des autres tiers</h5>

                <!-- Polar Area Chart -->
                <div id="autreParMois" style="max-height: 400px;"></div>
                


                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                    new ApexCharts(document.querySelector("#autreParMois"), {
                        series: [{
                        name: "Desktops",
                        data: [
                            <?php $__currentLoopData = $caMensuelAutre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camois): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            '<?php echo e($camois->ca); ?>',
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ]
                        }],
                        chart: {
                        // height: 350,
                        type: 'line',
                        zoom: {
                            enabled: false
                        }
                        },
                        dataLabels: {
                        enabled: false
                        },
                        stroke: {
                        curve: 'straight'
                        },
                        grid: {
                        row: {
                            colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
                            opacity: 0.5
                        },
                        },
                        xaxis: {
                        categories: [
                            <?php $__currentLoopData = $caMensuelAutre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camois): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            '<?php echo e($camois->mois."-".$camois->annee); ?>',
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ],
                        }
                    }).render();
                    });
                </script>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
              <div class="card">
              <div class="card-body" style="background-color: #ebebe8">
                  <h5 class="card-title">Chiffre d'affaire par les autres tiers</h5>

                  <!-- Polar Area Chart -->
                  <div id="parAutreTiers" style="max-height: 400px;"></div>
                  

                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                        new ApexCharts(document.querySelector("#parAutreTiers"), {
                            series: [
                                <?php $__currentLoopData = $caParAutretiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  '<?php echo e($autre->ca); ?>',
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ],
                            chart: {
                            type: 'polarArea',
                            // height: 5000,
                            toolbar: {
                                show: true
                            }
                            },
                            stroke: {
                            colors: ['#fff']
                            },
                            fill: {
                            opacity: 0.8
                            },
                            labels: [
                                <?php $__currentLoopData = $caParAutretiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  '<?php echo e($autre->nom." ".$autre->prenom." ".$autre->ca."Fcfa"); ?>',
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        ],
                        }).render();
                        });
                    </script>
                  <!-- End Polar Area Chart -->

              </div>
              </div>
          </div>

          <div class="col-lg-6">
            <div class="card">
              <div class="card-body " style="background-color: #ebebe8">
                <h5 class="card-title">Montant recouvré et non recouvré des autres tiers</h5>

                <!-- Doughnut Chart -->
                <div id="monatntRecouvre" style="max-height: 400px;"></div>
                


                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                    new ApexCharts(document.querySelector("#monatntRecouvre"), {
                        series: [<?php echo e($caTotalAutre); ?>, <?php echo e($montantNomRecouvreAutre); ?>],
                        chart: {
                        // height: 350,
                        type: 'donut',
                        toolbar: {
                            show: true
                        }
                        },
                        labels: [
                            'Montant rembourcé <?php echo e($caTotalAutre); ?> Fcfa',
                          'Montant non rembourcé <?php echo e($montantNomRecouvreAutre); ?> Fcfa'
                                    ],
                    }).render();
                    });
                </script>
                <!-- End Doughnut CHart -->

              </div>
            </div>
          </div>

          <hr>

          

        <div class="col-lg-12">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Achats mensuels auprès des fournisseurs </h5>

                <!-- Polar Area Chart -->
                <div id="achatParMois" style="max-height: 400px;"></div>
                

                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                        new ApexCharts(document.querySelector("#achatParMois"), {
                            series: [{
                            name: "Desktops",
                            data: [
                                <?php $__currentLoopData = $achatMensuel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    '<?php echo e($achat->ca); ?>',
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ]
                            }],
                            chart: {
                            // height: 350,
                            type: 'line',
                            zoom: {
                                enabled: false
                            }
                            },
                            dataLabels: {
                            enabled: false
                            },
                            stroke: {
                            curve: 'straight'
                            },
                            grid: {
                            row: {
                                colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
                                opacity: 0.5
                            },
                            },
                            xaxis: {
                            categories: [
                                <?php $__currentLoopData = $achatMensuel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  '<?php echo e($achat->mois."-".$achat->annee); ?>',
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ],
                            }
                        }).render();
                        });
                    </script>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
              <div class="card">
              <div class="card-body">
                  <h5 class="card-title">Achats par fournisseur </h5>

                  <!-- Polar Area Chart -->
                  <div id="achatParFournisseur" style="max-height: 400px;"></div>
                  

                    <script>
                        document.addEventListener("DOMContentLoaded", () => {
                        new ApexCharts(document.querySelector("#achatParFournisseur"), {
                            series: [
                                <?php $__currentLoopData = $achatParFournisseur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    '<?php echo e($fournisseur->ca); ?>',
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ],
                            chart: {
                            type: 'polarArea',
                            // height: 5000,
                            toolbar: {
                                show: true
                            }
                            },
                            stroke: {
                            colors: ['#fff']
                            },
                            fill: {
                            opacity: 0.8
                            },
                            labels: [
                                <?php $__currentLoopData = $achatParFournisseur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    '<?php echo e($fournisseur->nom." ".$fournisseur->prenom." ".$fournisseur->ca."Fcfa"); ?>',
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        ],
                        }).render();
                        });
                    </script>
                  <!-- End Polar Area Chart -->

              </div>
              </div>
          </div>

          <div class="col-lg-6">
            <div class="card">
              <div class="card-body ">
                <h5 class="card-title">Montant recouvré et non recouvré des autres tiers</h5>

                <!-- Doughnut Chart -->
                <div id="montantRegle" style="max-height: 400px;"></div>
                


                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                    new ApexCharts(document.querySelector("#montantRegle"), {
                        series: [<?php echo e($totalmontantRegle); ?>, <?php echo e($montantNonRegle); ?>],
                        chart: {
                            backgroundColor: [
                            '#8ce55c',
                            '#fe0002',
                          ],
                        // height: 350,
                        type: 'donut',
                        toolbar: {
                            show: true
                        }
                        },
                        labels: [
                            'Montant réglé <?php echo e($totalmontantRegle); ?> Fcfa',
                          'Montant non réglé <?php echo e($montantNonRegle); ?> Fcfa'
                                    ],
                    }).render();
                    });
                </script>
                <!-- End Doughnut CHart -->

              </div>
            </div>
          </div>



    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appTiers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion8.3\resources\views/tiers/home.blade.php ENDPATH**/ ?>