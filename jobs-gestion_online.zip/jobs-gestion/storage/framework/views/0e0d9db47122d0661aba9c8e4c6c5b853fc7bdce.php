<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-">
        <div class="card row">
            <div></div>
            <div>

            </div>
        </div>
    </div>

    <div class="col-sm-12"><div class="card">
        <div class="card-body">
          <div class="row">
            <div>
                <h5 class="card-title">Liste des encaissements</h5>
            </div>
            <div class="float-end">
              <button class="btn btn-success float-end me-5 mb-3" data-bs-toggle="modal" data-bs-target="#addencaissement">Ajouter</button>
            </div>
        </div>

          <!-- Table with stripped rows -->
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Caissier</th>
                <th scope="col">Déposant</th>
                <th scope="col">Somme</th>
                <th scope="col">Motif</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $encaissements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encaissement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($encaissement->num_piece); ?></th>
                    <td><?php echo e($encaissement->user->name); ?></td>
                    <td><?php echo e($encaissement->deposant); ?></td>
                    <td><?php echo e($encaissement->somme); ?></td>
                    <td><?php echo e($encaissement->motif); ?></td>
                    <td>

                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
          <!-- End Table with stripped rows -->
        </div>
      </div></div>

</div>

<div class="modal fade" id="addencaissement" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="card">
            <div class="modal-header">
                <div class="modal-title">
                    <h5> Encaissement</h5>

                </div>
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
        <div class="modal-body">
            <form class="row g-3 p-" method="POST" action="<?php echo e(route('caisse.encaissement.store')); ?>">
                <?php echo csrf_field(); ?>
                <div>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class=""><?php echo e($message); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-12 form-floating">
                  <input type="text" name="deposant" class="form-control" placeholder="Nom du déposant">
                  <label for="deposant"  class="form-label">Nom du déposant</label>
                </div>
                <div class="col-md-12 form-floating">
                  <input type="number" name="somme" class="form-control" placeholder="Somme">
                  <label for="somme" class="form-label">Somme</label>
                </div>
                <div class="col-md-12 form-floating">
                  <textarea name="motif" id="motif" cols="30" rows="10" class="form-control" placeholder="Motif de l'encaissement" style="height: 200px"></textarea>
                  <label for="motif" class="form-label">Motif</label>
                </div>
                <div class="">
                    <button type="submit" class="btn btn-success float-end">Valider</button>
                  </div>
              </form><!-- End No Labels Form -->
        </div>

      </div>
    </div>
  </div><!-- End Vertically centered Modal-->

</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WILLNER\Desktop\projet_jobs\27jan\jobs-gestion2.3-php\resources\views/caisse/encaissement.blade.php ENDPATH**/ ?>