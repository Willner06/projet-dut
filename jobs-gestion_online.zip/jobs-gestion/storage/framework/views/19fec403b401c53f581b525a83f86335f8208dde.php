<?php $__env->startSection('content'); ?>
    <div>
        <div class="pagetitle">
            <div class="">
                <h1><?php echo e($materiel->designation); ?></h1>
                <div class="card float-end">
                    <a class="badge text-bg-warning m-3" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalToggle"> Modifier </a>
                </div>
                <nav>
                    <ol class="breadcrumb">
                        
                        <li class="breadcrumb-item active"><a href="<?php echo e(route('materiel.index')); ?>">Matériel Ammorti</a></li>
                        <li class="breadcrumb-item active"><?php echo e($materiel->designation); ?></li>
                    </ol>
                </nav>
            <br><br>
            </div>

        </div><!-- End Page Title -->

        <div class="row">
            
                <div class="table-responsive card">
                    <table class="table-bordered">
                        <thead>
                            <tr>
                                <td colspan="7">
                                    <h4><u>Fiche d'immobilisation <?php echo e($materiel->designation); ?></u></h4>
                                </td>
                            </tr>
                        </thead>
                        <tbody class="">
                            <tr>
                                <td colspan="4">Code d'inventaire</td>
                                <td><?php echo e($materiel->code_inventaire); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Désignation</td>
                                <td><?php echo e($materiel->designation); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Type immobilisation</td>
                                <td><?php echo e($materiel->categorie->libelle); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Etat</td>
                                <td><?php echo e($materiel->etat); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Affectation</td>
                                <td><?php echo e($materiel->affectation); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Fournisseur</td>
                                <td><?php echo e($materiel->fournisseur); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Date d'acaht ou de mise en service</td>
                                <td><?php echo e($materiel->date_acquisition->format('d/m/Y')); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Prix d'achat</td>
                                <td><?php echo e($materiel->prix_achat .$monaie); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Autres frais</td>
                                <td><?php echo e($materiel->autres_frais .$monaie); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Coût d'acquisition TTC</td>
                                <td><?php echo e($materiel->cout_acquisitionTtc .$monaie); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">TVA déduite</td>
                                <td><?php echo e($materiel->tva .$monaie); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="7"><br></td>

                            </tr>
                            <tr>
                                <td colspan="4">BASE D'AMORTISSEMENT</td>
                                <td><?php echo e($materiel->base_ammortisable .$monaie); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                
                                
                            </tr>
                            <tr>
                                <td colspan="4"> Mode d'amortissement</td>
                                <td><?php echo e($materiel->mode_ammortissement); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Durée d'amortissement</td>
                                <td><?php echo e($materiel->duree_ammortissement); ?></td>
                                <td>Ans</td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="7"><br></td>
                            </tr>
                            <tr class="bg-primary text-white text-center">
                                <td></td>
                                <td>ANNEE</td>
                                <td>BASE</td>
                                <td>TAUX</td>
                                <td>CALCUL DE L'AMORTISSEMENT</td>
                                <td>AMORT.</td>
                                <td>V.N.C</td>
                            </tr>

                            <?php
                                $moisAcquisition=$materiel->date_acquisition->format('m');
                                $moisRestant= 12 - $moisAcquisition;

                                round($sommeParAnnee=$materiel->base_ammortisable / $materiel->duree_ammortissement,0);
                                round($taux=($sommeParAnnee * 100) / $materiel->base_ammortisable,0);

                                round(($sommeParMois=$sommeParAnnee / 12),0);
                                round($sommePremiereAnnee=$sommeParMois * $moisRestant,0);

                                round($sommeDerniereAnnee=$sommeParMois * $moisAcquisition,0);

                                $id=1;


                            ?>
                            <tr class="text-center">
                                <td>
                                    <?php echo e($id); ?>

                                </td>
                                <td>
                                    <?php echo e($annee=$materiel->date_acquisition->format('Y')); ?>

                                </td>
                                <td>
                                    <?php echo e($materiel->base_ammortisable .$monaie); ?>

                                </td>
                                <td>
                                    <?php echo e(round($taux,0)."%"); ?>

                                </td>
                                <td><?php echo e(round($sommePremiereAnnee,0) .$monaie); ?></td>
                                <td><?php echo e(round($sommePremiereAnnee,0) .$monaie); ?></td>
                                <td><?php echo e(round($materiel->base_ammortisable - $sommePremiereAnnee,0) .$monaie); ?></td>
                            </tr>
                            <?php
                                round($vnc=$materiel->base_ammortisable - $sommePremiereAnnee,0);
                                $id=2;
                                $annee=$annee+1;
                            ?>
                                <?php for($i = 1; $i < $materiel->duree_ammortissement; $i++): ?>

                                        <tr class="text-center">
                                            <td>
                                                <?php echo e($id++); ?>

                                            </td>
                                            <td>
                                                <?php echo e($annee++); ?>

                                            </td>
                                            <td>
                                                <?php echo e(round($materiel->base_ammortisable,0) .$monaie); ?>

                                            </td>
                                            <td>
                                                <?php echo e(round($taux,0)."%"); ?>

                                            </td>
                                            <td><?php echo e(round($materiel->base_ammortisable * $taux / 100,0) .$monaie); ?></td>
                                            <td><?php echo e(round($materiel->base_ammortisable * $taux / 100,0) .$monaie); ?></td>
                                            <td><?php echo e(round(($vnc=$vnc-($materiel->base_ammortisable * $taux / 100)),0) .$monaie); ?></td>
                                        </tr>
                                <?php endfor; ?>
                                <tr class="text-center">
                                    <td>
                                        <?php echo e($id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($annee); ?>

                                    </td>
                                    <td>
                                        <?php echo e(round($materiel->base_ammortisable,0) .$monaie); ?>

                                    </td>
                                    <td>
                                        <?php echo e(round($taux,0)."%"); ?>

                                    </td>
                                    <td><?php echo e(round($sommeDerniereAnnee,0) .$monaie); ?></td>
                                    <td><?php echo e(round($sommeDerniereAnnee,0) .$monaie); ?></td>
                                    <td><?php echo e(round($vnc-$sommeDerniereAnnee,0) .$monaie); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="7"><br></td>
                                </tr>


                                
                                <tr>
                                    <td colspan="7" class="text-center bg-danger text-white">
                                        CESSION, MISE AU REBUT, REINTEGRATION AU PATRIMOINE PERSONNEL :
                                    </td>
                                </tr>


                                <tr class="">
                                    <td colspan="4">
                                        Date de mise au rebut :
                                    </td>
                                    <td>
                                        <?php echo e($materiel->date_mise_au_rebut); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        Date de cession :
                                    </td>
                                    <td>
                                        <?php echo e($materiel->date_session); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        Valeur Nette Comptable :
                                    </td>
                                    <td>
                                        <?php echo e($materiel->valeur_net_comptable); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        Prix de vente ou valeur de reprise :
                                    </td>
                                    <td>
                                        <?php echo e($materiel->prix_vente_valeur_reprise); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        <b><u>Plus-value globale :</u></b>
                                    </td>
                                    <td>
                                        <?php echo e($materiel->plus_value_globale); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        Dont à COURT TERME :
                                    </td>
                                    <td>
                                        <?php echo e($materiel->dont_court_terme); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        Dont à LONG TERME :
                                    </td>
                                    <td>
                                        <?php echo e($materiel->dont_long_terme); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>
                                



                        </tbody>
                    </table>
                </div>
        </div>
    </div>



    <div class="modal modal-lg fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-title">
                <h3 class="m-3"><?php echo e($materiel->designation); ?></h3>
            </div>
            <div class="modal-body">
                <form class="row g-3" method="post" action="<?php echo e(route('materiel.update', $materiel->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="col-md-6">
                        <label for="categorie" class="form-label">Catégorie (Type immobilisation)</label>
                        
                        <select class="form-select" id="categorie_id" name="categorie_id" >
                            <option selected value="<?php echo e($materiel->categorie->id); ?>"><?php echo e($materiel->categorie->libelle); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option selected value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->libelle); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="code_inventaire" class="form-label">Code inventaire</label>
                        <input type="text" class="form-control" id="code_inventaire" name="code_inventaire" value="<?php echo e($materiel->code_inventaire); ?>" >
                    </div>
                    
                    <div class="col-md-6">
                      <label for="designation" class="form-label">Désignation</label>
                      <input type="text" class="form-control" id="designation" name="designation" value="<?php echo e($materiel->designation); ?>" >
                    </div>

                    <div class="col-md-6">
                        <label for="date_acquisition" class="form-label">Date d'achat ou mise en service</label>
                        <input type="date" class="form-control" id="date_acquisition" name="date_acquisition" value="<?php echo e($materiel->date_acquisition); ?>" placeholder="<?php echo e($materiel->date_acquisition); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label for="prix_achat" class="form-label">Prix d'achat</label>
                        <input type="number" class="form-control" id="prix_achat" name="prix_achat" value="<?php echo e($materiel->prix_achat); ?>" >
                    </div>
                    <div class="col-md-3">
                        <label for="autres_frais" class="form-label">Autres frais</label>
                        <input type="number" class="form-control" id="autres_frais" name="autres_frais" value="<?php echo e($materiel->autres_frais); ?>" >
                    </div>
                    <div class="col-md-3">
                        <label for="cout_acquisitionTtc" class="form-label">Coût d'acquisition TTC</label>
                        <input type="number" class="form-control" id="cout_acquisitionTtc" name="cout_acquisitionTtc" value="<?php echo e($materiel->cout_acquisitionTtc); ?>" >
                    </div>
                    <div class="col-md-3">
                        <label for="tva" class="form-label">TVA déduite</label>
                        <input type="number" class="form-control" id="tva" name="tva" value="<?php echo e($materiel->tva); ?>" >
                    </div>
                    <div class="col-md-4">
                        <label for="affectation" class="form-label">Affectation</label>
                        <input type="text" class="form-control" id="affectation" name="affectation" value="<?php echo e($materiel->affectation); ?>" >
                    </div>
                    <div class="col-md-4">
                        <label for="etat" class="form-label">Etat</label>
                        <input type="text" class="form-control" id="etat" name="etat" value="<?php echo e($materiel->etat); ?>" >
                    </div>
                    <div class="col-md-4">
                        <label for="fournisseur" class="form-label">Fournisseur</label>
                        <input type="text" class="form-control" id="fournisseur" name="fournisseur" value="<?php echo e($materiel->fournisseur); ?>" >
                    </div>


                    <div class="col-md-4">
                        <label for="base_ammortisable" class="form-label">Base ammortissable</label>
                        <input type="number" class="form-control" id="base_ammortisable" name="base_ammortisable" value="<?php echo e($materiel->base_ammortisable); ?>" >
                    </div>
                    <div class="col-md-4">
                        <label for="mode_ammortissement" class="form-label">Mode d'ammortissement</label>
                        <input type="text" class="form-control" id="mode_ammortissement" name="mode_ammortissement" value="<?php echo e($materiel->mode_ammortissement); ?>" >
                    </div>
                    <div class="col-md-4">
                        <label for="duree_ammortissement" class="form-label">Durée d'ammortissement</label>
                        <input type="number" class="form-control" id="duree_ammortissement" name="duree_ammortissement" value="<?php echo e($materiel->duree_ammortissement); ?>" >
                    </div>


                    <div class="col-md-4">
                        <label for="date_mise_au_rebut" class="form-label">Date mise au rebut</label>
                        <input type="date" class="form-control" id="date_mise_au_rebut" name="date_mise_au_rebut" value="<?php echo e($materiel->date_mise_au_rebut); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="date_session" class="form-label">Date session</label>
                        <input type="date" class="form-control" id="date_session" name="date_session" value="<?php echo e($materiel->date_session); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="valeur_net_comptable" class="form-label">Valeur net comptable</label>
                        <input type="number" class="form-control" id="valeur_net_comptable" name="valeur_net_comptable" value="<?php echo e($materiel->valeur_net_comptable); ?>" >
                    </div>
                    <div class="col-md-6">
                        <label for="prix_vente_valeur_reprise" class="form-label">Prix vente valeur reprise</label>
                        <input type="number" class="form-control" id="prix_vente_valeur_reprise" name="prix_vente_valeur_reprise" value="<?php echo e($materiel->prix_vente_valeur_reprise); ?>" >
                    </div>
                    <div class="col-md-6">
                        <label for="plus_value_globale" class="form-label">Plus value globale</label>
                        <input type="number" class="form-control" id="plus_value_globale" name="plus_value_globale" value="<?php echo e($materiel->plus_value_globale); ?>" >
                    </div>
                    <div class="col-md-6">
                        <label for="dont_court_terme" class="form-label">Dont court terme</label>
                        <input type="number" class="form-control" id="dont_court_terme" name="dont_court_terme" value="<?php echo e($materiel->dont_court_terme); ?>" >
                    </div>
                    <div class="col-md-6">
                        <label for="dont_long_terme" class="form-label">Dont long terme</label>
                        <input type="number" class="form-control" id="dont_long_terme" name="dont_long_terme" value="<?php echo e($materiel->dont_long_terme); ?>" >
                    </div>

                    <div class="col-12">
                      <button class="btn btn-success float-end" type="submit">Valider</button>
                    </div>
                  </form>
            </div>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appImmo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobs-gestion9.6\resources\views/immobilisation/showMateriel.blade.php ENDPATH**/ ?>