<?php $__env->startSection('content'); ?>

<div>
    <div class="pagetitle">
        <div class="">
            <h1>Type de matériel non ammortissables</h1>
            <div class="card float-end">
                <button class="badge text-bg-success m-3" type="button" data-bs-toggle="modal" data-bs-target="#addMateriel"> <i class="bi bi-plus-lg"></i>Type de matériel     </button>
            </div>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Type de matériel</a></li>
                </ol>
            </nav>
        <br><br>
        </div>

    </div><!-- End Page Title -->


    <div class="row">
        <div class="row">
            
            <div class="table-responsive bg-body-secondary">
                <table class="table datatable">
                    <thead>
                        <th>ID</th>
                        <th>Type de matériel</th>
                        <th>Nombre de matériel</th>
                        <th>Action</th>
                    </thead>

                    <tbody>
                        <?php
                            $nombre=0;
                        ?>
                        <?php $__currentLoopData = $intermediaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intermediaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php

                                foreach ($intermediaire->entres as $entre) {
                                    $nombre=$nombre+$entre->quantite;
                                }
                            ?>

                        <tr>
                            <td><?php echo e($intermediaire->id); ?></td>
                            <td><?php echo e($intermediaire->designation); ?></td>
                            <td><?php echo e($nombre); ?></td>
                            <td>

                                <a href="<?php echo e(route('materiel.intermediaire.show',$intermediaire->id)); ?>" class=" text-bg-warning badge">Afficher</a>
                                <form class="d-inline" action="<?php echo e(route('materiel.intermediaire.delete',$intermediaire->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="card-link text-bg-danger badge" onclick=" return confirm('Êtes vous sûr de vouloir supprimer?')">supprimer </button>
                                </form>


                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                    <tfoot>
                        <tr>

                        </tr>
                    </tfoot>
                </table>

            </div>
        </div>
    </div>

</div>
</section>


<div class="modal fade" id="addMateriel" tabindex="-1">
<div class="modal-dialog modal-dialog">
  <div class="modal-content">
    <div class="card">
        <div class="modal-header">
            <div class="modal-title">
                <h5> Matériel</h5>

            </div>
            <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
    <div class="modal-body">
        <form class="row g-3 p-" method="POST" action="<?php echo e(route('materiel.intermediaire.store')); ?>">
            <?php echo csrf_field(); ?>
            <div>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class=""><?php echo e($message); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-12 form-floating">
              <input type="text" class="form-control" name="designation" placeholder="designation">
              <label for="designation"  class="form-label">Désignation</label>
            </div>

            <div class="">
                <button type="submit" class="btn btn-success float-end">Valider</button>
            </div>
          </form><!-- End No Labels Form -->
    </div>

  </div>
</div>
</div><!-- End Vertically centered Modal-->




</div>


<?php if(Session::has('message')): ?>

<script>
    toastr.success("<?php echo Session::get('message'); ?>");
</script>

<?php endif; ?>

<?php if($errors->all()): ?>

<script>
    toastr.error("Une erreur c'est produite");
</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appImmo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobs-gestion13\resources\views/immobilisation/intermediaire/index.blade.php ENDPATH**/ ?>