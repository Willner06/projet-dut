<?php $__env->startSection('content'); ?>

<div>
    <div class="pagetitle">
        <div class="">
            <h1>Liste des rôles</h1>
            <div class="card float-end">
                <button class="badge text-bg-success m-3" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalToggle"> <i class="bi bi-plus-lg"></i> Rôles </button>
            </div>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                    <li class="breadcrumb-item active">Rôles</li>
                </ol>
            </nav>
        <br><br>
        </div>

    </div><!-- End Page Title -->

    <div class="row">
        <div class="table-responsive card">
            <table class="datatable text-center ">
                <thead>
                    <tr>
                        <th class="text-center">N°</th>
                        <th class="text-center">Nom</th>
                        <th class="text-center">Action</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($id++); ?></td>
                        <td><?php echo e($role->name); ?></td>
                        <td>
                            
                            <a href="<?php echo e(route('roles.edit', $role->id)); ?>"class="text-bg-success badge">Afficher</a>
                            
                            <form class="d-inline" action="<?php echo e(route('roles.destroy',$role->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="text-bg-danger badge" onclick="return confirm('Êtes vous sûr de vouloir supprimer?')">Supprimer</button>
                            </form>
                            
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>

                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <div class="modal modal-lg fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
        <div class="modal-dialog modal-dialog">
          <div class="modal-content">
            <div class="modal-body">
                <form class="row g-3 needs-validation" novalidate action="<?php echo e(route('roles.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-danger" class=""><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                      <div class="col-12">
                        <label for="name" class="form-label">Nom</label>
                        <input type="text" name="name" class="form-control" id="name" required>
                        
                      </div>
                      <div class="col-12">
                        <label for="categorie" class="form-label">Permissions:</label><br>
                        
                            <div class="row">

                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-6">
                                        <div class="d-inline">
                                            <input class="form-checkbox-inline" name="permission_id[]" id="permission_id-<?php echo e($permission->id); ?>" type="checkbox" value="<?php echo e($permission->id); ?> "<?php echo e($permission->name); ?> > <label for="permission_id-<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></label>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        
                        </div>



                      <div class="col-sm-12 text-center">
                        <button class="btn btn-success col-3 mt-3" type="submit">Enregistrer</button>
                      </div>
                    </form>
            </div>
          </div>
        </div>
      </div>

</div>



<?php if(Session::has('message')): ?>

<script>
    toastr.success("<?php echo Session::get('message'); ?>");
</script>

<?php endif; ?>


<?php if($errors->all()): ?>

<script>
    toastr.error("Une erreur c'est produite");
</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobs-gestion21.5\resources\views/role/index.blade.php ENDPATH**/ ?>