<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-">
        <div class="card row">
            <div></div>
            <div>

            </div>
        </div>
    </div>

    <div class="col-sm-12"><div class="card">
        <div class="card-body">
          <div class="row">
            <div>
                <h5 class="card-title">Liste des decaissements</h5>
            </div>
            <div class="float-end">
              <button class="btn btn-success float-end me-5 mb-3" data-bs-toggle="modal" data-bs-target="#adddecaissement">Ajouter</button>
            </div>
        </div>

          <!-- Table with stripped rows -->
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Caissier</th>
                <th scope="col">Deumandeur</th>
                <th scope="col">Somme</th>
                <th scope="col">Motif</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $decaissements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decaissement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($decaissement->num_piece); ?></th>
                    <td><?php echo e($decaissement->user->name); ?></td>
                    <td><?php echo e($decaissement->demandeur); ?></td>
                    <td><?php echo e($decaissement->somme); ?></td>
                    <td>
                    <?php echo e($decaissement->motif->libelle); ?>

                    </td>
                    <td>

                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
          <!-- End Table with stripped rows -->
        </div>
      </div></div>

</div>

<div class="modal fade" id="adddecaissement" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="card">
            <div class="modal-header">
                <div class="modal-title">
                    <h5> Décaissement</h5>

                </div>
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
        <div class="modal-body">
            <form class="row g-3 p-" method="POST" action="<?php echo e(route('caisse.decaissement.store')); ?>">
                <?php echo csrf_field(); ?>
                <div>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class=""><?php echo e($message); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-12 form-floating">
                  <input type="text" name="demandeur" class="form-control" placeholder="Nom du déposant" required>
                  <label for="demandeur"  class="form-label">Nom du demandeur</label>
                </div>
                <div class="col-md-12 form-floating">
                  <input type="number" name="somme" class="form-control" placeholder="Somme" required>
                  <label for="somme" class="form-label">Somme</label>
                </div>
                <div class="col-md-12" >

                    <label class="form-label" for="">Motif(s)</label>
                    <div class="form-control p-3"  style="overflow: auto; height:130px">
                        <input type="radio" name="motif" class="form-check-input " id="1" value="prospection">
                        <label for="1" class="form-label">Prospection</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="survey" id="2">
                        <label for="2" class="form-label">Survey</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="intervention" id="3">
                        <label for="3" class="form-label">Intervention</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="procedure administrative" id="4">
                        <label for="4" class="form-label">Procedure administrative</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="livraison sur vente" id="5">
                        <label for="5" class="form-label">Livraison sur vente</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="carburant" id="6">
                        <label for="6" class="form-label">Carburant</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="communication" id="7">
                        <label for="7" class="form-label">Communication</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="autre" id="autre">
                        <label for="autre" class="form-label">autre</label>
                    </div>

                </div>
                <div class="col-md-12 form-floating">
                    <textarea name="description" id="description" cols="30" rows="10" class="form-control" placeholder="Décrire en quelques ligne le motif" style="height: 200px" required></textarea>
                    <label for="description" class="form-label">Décrire en quelques ligne le motif</label>
                  </div>
                <div class="">
                    <button type="submit" class="btn btn-success float-end">Valider</button>
                  </div>
              </form><!-- End No Labels Form -->
        </div>

      </div>
    </div>
  </div><!-- End Vertically centered Modal-->

</div>
</div>
</div>

<script>
        $(document).ready(function() {
            toastr.options.timeOut = 10000;
            <?php if(Session::has('error')): ?>
                toastr.error('<?php echo e(Session::get('error')); ?>');
            <?php elseif(Session::has('success')): ?>
                toastr.success('<?php echo e(Session::get('success')); ?>');
            <?php endif; ?>
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion5.4\resources\views/caisse/indexDecaissement.blade.php ENDPATH**/ ?>