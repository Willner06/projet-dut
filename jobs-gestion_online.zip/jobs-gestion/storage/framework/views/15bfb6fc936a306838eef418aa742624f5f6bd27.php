<?php $__env->startSection('content'); ?>
    <div>
        <div class="pagetitle">
            <div class="">
                <h1><?php echo e($materiel->designation); ?></h1>
                
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active">Materiels</li>
                        <li class="breadcrumb-item active"><?php echo e($materiel->designation); ?></li>
                    </ol>
                </nav>
            <br><br>
            </div>

        </div><!-- End Page Title -->

        <div class="row">
            
                <div class="table-responsive card">
                    <table class="table-bordered">
                        <thead>
                            <tr>
                                <td colspan="7">
                                    <h4><u>Fiche d'immobilisation <?php echo e($materiel->designation); ?></u></h4>
                                </td>
                            </tr>
                        </thead>
                        <tbody class="">
                            <tr>
                                <td colspan="4">Code d'inventaire</td>
                                <td><?php echo e($materiel->code_inventaire); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Désignation</td>
                                <td><?php echo e($materiel->designation); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Type immobilisation</td>
                                <td><?php echo e($materiel->categorie->libelle); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Etat</td>
                                <td><?php echo e($materiel->etat); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Affectation</td>
                                <td><?php echo e($materiel->affectation); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Fournisseur</td>
                                <td><?php echo e($materiel->fournisseur); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Date d'acaht ou de mise en service</td>
                                <td><?php echo e($materiel->date_acquisition); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Prix d'achat</td>
                                <td><?php echo e($materiel->prix_achat); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Autres frais</td>
                                <td><?php echo e($materiel->autres_frais); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Coût d'acquisition TTC</td>
                                <td><?php echo e($materiel->cout_acquisitionTtc); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">TVA déduite</td>
                                <td><?php echo e($materiel->tva); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="7"></td>

                            </tr>
                            <tr>
                                <td colspan="4">BASE D'AMORTISSEMENT</td>
                                <td><?php echo e($materiel->base_ammortisable); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="7"></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4"> Mode d'amortissement</td>
                                <td><?php echo e($materiel->mode_ammortissement); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="4">Durée d'amortissement</td>
                                <td><?php echo e($materiel->duree_ammortissement); ?></td>
                                <td>Ans</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr class="bg-primary text-white">
                                <td></td>
                                <td>ANNEE</td>
                                <td>BASE</td>
                                <td>TAUX</td>
                                <td>CALCUL DE L'AMORTISSEMENT</td>
                                <td>AMORT.</td>
                                <td>V.N.C</td>
                            </tr>

                                
                                        <tr>
                                            <td>

                                            </td>
                                            <td>

                                            </td>
                                            <td>
                                                <?php echo e(($materiel->duree_ammortissement*100)/100); ?>

                                            </td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                

                        </tbody>
                    </table>
                </div>
        </div>
    </div>



    <div class="modal modal-lg fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-title">
                <h3 class="m-3">Ajout d'un matériel</h3>
            </div>
            <div class="modal-body">
                <form class="row g-3" method="post" action="<?php echo e(route('materiel.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6">
                        <label for="categorie" class="form-label">Catégorie (Type immobilisation)</label>
                        <input type="text" class="form-control" id="categorie_id" name="categorie_id" required>
                        
                    </div>
                    <div class="col-md-6">
                        <label for="code_inventaire" class="form-label">Code inventaire</label>
                        <input type="text" class="form-control" id="code_inventaire" name="code_inventaire" required>
                    </div>
                    
                    <div class="col-md-6">
                      <label for="designation" class="form-label">Désignation</label>
                      <input type="text" class="form-control" id="designation" name="designation" required>
                    </div>

                    <div class="col-md-6">
                        <label for="date_acquisition" class="form-label">Date d'achat ou mise en service</label>
                        <input type="date" class="form-control" id="date_acquisition" name="date_acquisition" required>
                    </div>
                    <div class="col-md-3">
                        <label for="prix_achat" class="form-label">Prix d'achat</label>
                        <input type="number" class="form-control" id="prix_achat" name="prix_achat" required>
                    </div>
                    <div class="col-md-3">
                        <label for="autres_frais" class="form-label">Autres frais</label>
                        <input type="number" class="form-control" id="autres_frais" name="autres_frais" required>
                    </div>
                    <div class="col-md-3">
                        <label for="cout_acquisitionTtc" class="form-label">Coût d'acquisition TTC</label>
                        <input type="number" class="form-control" id="cout_acquisitionTtc" name="cout_acquisitionTtc" required>
                    </div>
                    <div class="col-md-3">
                        <label for="tva" class="form-label">TVA déduite</label>
                        <input type="number" class="form-control" id="tva" name="tva" required>
                    </div>
                    <div class="col-md-4">
                        <label for="affectation" class="form-label">Affectation</label>
                        <input type="text" class="form-control" id="affectation" name="affectation" required>
                    </div>
                    <div class="col-md-4">
                        <label for="etat" class="form-label">Etat</label>
                        <input type="text" class="form-control" id="etat" name="etat" required>
                    </div>
                    <div class="col-md-4">
                        <label for="fournisseur" class="form-label">Fournisseur</label>
                        <input type="text" class="form-control" id="fournisseur" name="fournisseur" required>
                    </div>


                    <div class="col-md-12">
                        <label for="base_ammortisable" class="form-label">Base ammortissable</label>
                        <input type="number" class="form-control" id="base_ammortisable" name="base_ammortisable" required>
                    </div>
                    <div class="col-md-6">
                        <label for="mode_ammortissement" class="form-label">Mode d'ammortissement</label>
                        <input type="text" class="form-control" id="mode_ammortissement" name="mode_ammortissement" required>
                    </div>
                    <div class="col-md-6">
                        <label for="duree_ammortissement" class="form-label">Durée d'ammortissement</label>
                        <input type="number" class="form-control" id="duree_ammortissement" name="duree_ammortissement" required>
                    </div>
                    <div class="col-12">
                      <button class="btn btn-success float-end" type="submit">Valider</button>
                    </div>
                  </form>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2" tabindex="-1">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appImmo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion7.5\resources\views/immobilisation/showMateriel.blade.php ENDPATH**/ ?>