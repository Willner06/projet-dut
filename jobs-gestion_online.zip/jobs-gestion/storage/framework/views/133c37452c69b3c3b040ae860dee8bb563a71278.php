

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('marchandise.categorie.index')); ?>">

          <span>Catégories</span>
        </a>
      </li><!-- End F.A.Q Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('marchandise.index')); ?>">

          <span>Marchandises</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('marchandise.entres')); ?>">

          <span>Entrées</span>
        </a>
      </li><!-- End Profile Page Nav -->


      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('marchandise.sorties')); ?>">

          <span>Sorties</span>
        </a>
      </li><!-- End Profile Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('marchandise.inventaire.index')); ?>">

          <span>Inventaires</span>
        </a>
      </li><!-- End Contact Page Nav -->

    </ul>

  </aside><!-- End Sidebar-->
<?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion6.6\resources\views/layouts/navbarMarchandise.blade.php ENDPATH**/ ?>