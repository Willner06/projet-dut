<?php $__env->startSection('content'); ?>
    <section>
       <div class="row">
        <div class="pagetitle">
            <div class="">
                <h1><?php echo e(ucfirst($intermediaire->designation)); ?></h1>
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('materiel.intermediaire.index')); ?>">Tpe de produit </a></li>
                        <li class="breadcrumb-item active"><?php echo e(ucfirst($intermediaire->designation)); ?></li>
                    </ol>
                </nav>
            </div>

            <div class="card float-end me-5">
                <div class="row p-1">
                    
                    <div class="">
                        <a class="badge text-bg-success w-100" type="button" data-bs-toggle="modal" data-bs-target="#addEntre">  <i class="bi bi-plus-lg"> Ajouter</i></a>
                    </div>
                </div>
            </div>

            
        </div><!-- End Page Title -->


        <div class="row">
                

                

                
            <div class="table-responsive">
                <div class="col-lg-12">

                    <div class="card">
                      <div class="card-body bg-body-secondary">

                        <!-- Default Tabs -->
                        
                        <div class="tab-content pt-2" id="myTabjustifiedContent">
                          <div class="tab-pane fade show active table-responsive" id="home-justified" role="tabpanel" aria-labelledby="home-tab">
                            <table class="datatable">
                                <thead>
                                    <tr class="text-center">
                                        <th>Date d'achat</th>
                                        
                                        <th>Quantité</th>
                                        <th>Prix unitaire</th>
                                        <th>Coût total</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $intermediaire->entres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="">
                                            <td><?php echo e($entre->date_achat); ?></td>
                                            
                                            <td><?php echo e($entre->quantite); ?></td>
                                            <td><?php echo e($entre->cout_achat." " .$monaie); ?></td>
                                            <td><?php echo e($entre->quantite * $entre->cout_achat." ".$monaie); ?></td>
                                            <td class="d-inline">
                                                <div class="d-inline">
                                                    <a class="badge text-bg-warning " type="button" data-bs-toggle="modal" data-bs-target="#updateEntre-<?php echo e($entre->id); ?>"> Modifier</i></a>

                                                <form class="d-inline" action="<?php echo e(route('materiel.entre.delete',$entre->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="submit" class="card-link text-bg-danger badge" onclick=" return confirm('Êtes vous sûr de vouloir supprimer?')">supprimer </button>
                                                </form>
                                                </div>
                                            </td>
                                        </tr>


                                        <div class="modal fade" id="updateEntre-<?php echo e($entre->id); ?>" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
                                            <div class="modal-dialog modal-dialog-centered">
                                              <div class="modal-content">
                                                <div class="modal-body">
                                                    <form class="row g-3" method="post" action="<?php echo e(route('materiel.entre.update', $entre->id)); ?>">
                                                        <?php echo method_field('put'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <div>
                                                            <ul>
                                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li class=""><?php echo e($message); ?></li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </div>
                                                        
                                                        <div class="col-md-12">
                                                          <label for="quantite" class="form-label">Quantité</label>
                                                          <input type="number" class="form-control" id="quantite" name="quantite" value="<?php echo e($entre->quantite); ?>" required>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <label for="cout_achat" class="form-label">Coût d'achat</label>
                                                            <input type="number" class="form-control" id="cout_achat" name="cout_achat" value="<?php echo e($entre->cout_achat); ?>" required>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <label for="date_achat" class="form-label">Date achat</label>
                                                            <input type="date" class="form-control" id="date_achat" name="date_achat" value="<?php echo e($entre->date_achat); ?>" required>
                                                        </div>


                                                        
                                                        <div class="col-12">
                                                          <button name="materiel_id" value="<?php echo e($intermediaire->id); ?>" class="btn btn-success float-end" type="submit">Valider</button>
                                                        </div>
                                                      </form>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>


                            </table>
                          </div>
                          

                  </div>

            </div>
        </div>
       </div>
    </section>








    <div class="modal fade" id="addEntre" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
                <form class="row g-3" method="post" action="<?php echo e(route('materiel.entre.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class=""><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    
                    <div class="col-md-12">
                      <label for="quantite" class="form-label">Quantité</label>
                      <input type="number" class="form-control" id="quantite" name="quantite" required>
                    </div>
                    <div class="col-md-12">
                        <label for="cout_achat" class="form-label">Coût d'achat</label>
                        <input type="number" class="form-control" id="cout_achat" name="cout_achat" required>
                    </div>
                    <div class="col-md-12">
                        <label for="date_achat" class="form-label">Date achat</label>
                        <input type="date" class="form-control" id="date_achat" name="date_achat" required>
                    </div>


                    
                    <div class="col-12">
                      <button name="materiel_id" value="<?php echo e($intermediaire->id); ?>" class="btn btn-success float-end" type="submit">Valider</button>
                    </div>
                  </form>
            </div>
          </div>
        </div>
      </div>


      


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appImmo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobs-gestion21.3\resources\views/immobilisation/intermediaire/show.blade.php ENDPATH**/ ?>