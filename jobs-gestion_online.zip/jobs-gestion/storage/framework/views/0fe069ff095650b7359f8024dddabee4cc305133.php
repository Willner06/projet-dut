<?php $__env->startSection('content'); ?>

<div>
    <div class="pagetitle">
        <div class="">
            <h1>Utilisateurs</h1>
            <div class="card float-end">
                <button class="badge text-bg-success m-3" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalToggle"> <i class="bi bi-plus-lg"></i> Utilisateur </button>
            </div>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        <br><br>
        </div>

    </div><!-- End Page Title -->

    <div class="row">
        <div class="table-responsive card">
            <table class="datatable">
                <thead>
                    <tr>
                        <th>N°</th>
                        <th>Nom(s)</th>
                        <th>Prénom(s)</th>
                        <th>Email</th>
                        <th>Fonction</th>
                        <th>Action</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($id++); ?></td>
                        <td><?php echo e($user->nom); ?></td>
                        <td><?php echo e($user->prenom); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->fonction); ?></td>
                        <td>
                            <a href="<?php echo e(route('user.show', $user->id)); ?>" class=" text-bg-warning badge">Voir</a>
                            <?php if($user->email != Auth::user()->email): ?>
                            <form class="d-inline" action="<?php echo e(route('user.destroy',$user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="text-bg-danger badge" onclick="return confirm('Êtes vous sûr de vouloir supprimer?')">Supprimer</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>

                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
                <form class="row g-3 needs-validation" novalidate action="<?php echo e(route('user.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-danger" class=""><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                      <div class="col-12">
                        <label for="nom" class="form-label">Nom(s)</label>
                        <input type="text" name="nom" class="form-control" id="nom" required>
                        
                      </div>

                      <div class="col-12">
                        <label for="prenom" class="form-label">Prénom(s)</label>
                        <input type="text" name="prenom" class="form-control" id="prenom" required>
                        
                      </div>

                      <div class="col-12">
                        <label for="fonction" class="form-label">Fonction</label>
                        <input type="text" name="fonction" class="form-control" id="fonction" required>
                        
                      </div>


                      <div class="col-12">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" id="email" required>
                        
                      </div>

                      <div class="col-12">
                        <label for="yourPassword" class="form-label">Mot de passe</label>
                        <input type="password" name="password" class="form-control" id="yourPassword" required>
                        
                      </div>

                      <div class="col-12">
                        <label for="yourPassword_confirm" class="form-label">Confirmation mot de passe</label>
                        <input type="password" name="password_confirm" class="form-control" id="yourPassword_confirm" required>
                        
                      </div>

                      <div class="col-12">
                        <button class="btn btn-primary w-100" type="submit">Ajouter un utilisateur</button>
                      </div>
                    </form>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2" tabindex="-1">

</div>



<?php if(Session::has('message')): ?>

<script>
    toastr.success("<?php echo Session::get('message'); ?>");
</script>

<?php endif; ?>


<?php if($errors->all()): ?>

<script>
    toastr.error("Une erreur c'est produite");
</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appTiers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobs-gestion9.6\resources\views/user/create.blade.php ENDPATH**/ ?>