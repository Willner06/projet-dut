<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <div class="">
        <h1>Décaissements</h1>
        <nav>
            <ol class="breadcrumb">
                
                <li class="breadcrumb-item active">Décaissements</li>
            </ol>
        </nav>
    </div>

</div><!-- End Page Title -->
<div class="row">

    <div class="col-sm-12"><div class="">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Créer les décaissements')): ?>
        <div class="card-body">

            <div class="float-end card" >
              <button class="btn btn-success float-end m-2" data-bs-toggle="modal" data-bs-target="#adddecaissement">Ajouter</button>
            </div><br><br><br>
        </div>
        <?php endif; ?>

          <!-- Table with stripped rows -->
          <div class="card">
            <div style="box-shadow: 1px 1px 10px black;" class="table-responsive">
                <table class="table table-striped datatable text-center" >
                    <thead>
                      <tr>
                        <th class="text-center" scope="col">N° pièce</th>
                        <th class="text-center" scope="col">Caissier</th>
                        <th class="text-center" scope="col">Date</th>
                        <th class="text-center" scope="col">Demandeur(s)</th>
                        <th class="text-center" scope="col">Autorisé par</th>
                        <th class="text-center" scope="col">Montant</th>
                        <th class="text-center" scope="col">Motif</th>
                        <th class="text-center" scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $decaissements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decaissement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($decaissement->num_piece); ?></th>
                            <td><?php echo e($decaissement->user->nom); ?></td>
                            <td><?php echo e($decaissement->created_at->format('d/m/Y')); ?></td>
                            <td>
                                <?php $__currentLoopData = $decaissement->employes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($employe->nom.' '.$employe->prenom.';' ?? ''); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($decaissement->autorisePar); ?></td>
                            <td><?php echo e(number_format($decaissement->somme,0,'.',' ')." ".$monaie); ?></td>
                            <td>
                            <?php echo e($decaissement->motif->libelle); ?>

                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Imprimer les encaissements')): ?>
                                    <a href="<?php echo e(route('caisse.decaissement.export',$decaissement->id)); ?>" target="_blank" class="badge m-3 text-bg-primary">Imprimer</a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Modifier les décaissements')): ?>
                                    <?php if($decaissement->etat == "controlle"): ?>

                                    <?php else: ?>
                                        <a href="#" class="badge m-3 text-bg-warning" data-bs-toggle="modal" data-bs-target="#updateDecaissement-<?php echo e($decaissement->id); ?>">Modifier</a>
                                    <?php endif; ?>
                                <?php endif; ?>

                            </td>


                            <div class="modal fade" id="updateDecaissement-<?php echo e($decaissement->id); ?>" tabindex="-1">
                                <div class="modal-dialog modal-dialog-centered">
                                  <div class="modal-content">
                                    <div class="card">
                                        <div class="modal-header">
                                            <div class="modal-title">
                                                <h5>Modification du décaissement</h5>

                                            </div>
                                            <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form class="row g-3 needs-validation" novalidate method="POST" action="<?php echo e(route('caisse.decaissement.update', $decaissement->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                                            <div>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class=""><?php echo e($message); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="col-md-12">
                                              <label for="employe_id" id="demandeur"  class="form-label">Nom du demandeur</label>
                                                <select class="form-select" multiple="multiple " id="employe_id" name="employe_id[]" required>

                                                    

                                                    <?php $__currentLoopData = $employers->unique('nom', 'prenom'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <option  value="<?php echo e($employer->id); ?>" ><?php echo e($employer->nom." ".$employer->prenom); ?></option>


                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-12">
                                              <label for="code" class="form-label">Code</label>
                                              <input type="number" id="code" name="code" class="form-control" required value="<?php echo e($decaissement->code); ?>">
                                            </div>
                                            <div class="col-md-12">
                                              <label for="somme" class="form-label">Montant</label>
                                              <input type="number" id="somme" name="somme" class="form-control" value="<?php echo e($decaissement->somme); ?>" required>

                                            </div>
                                            
                                            <div class="col-md-12" >

                                                <label class="form-label" for="">Motif(s)</label>
                                                <div class="form-control p-3"  style="overflow: auto; height:130px">
                                                    <?php if($decaissement->motif->libelle == "prospection"): ?>
                                                        <input type="radio" name="motif" class="form-check-input " id="1" value="prospection" checked>
                                                        <label for="1" class="form-label">Prospection</label><br>
                                                    <?php else: ?>
                                                        <input type="radio" name="motif" class="form-check-input " id="1" value="prospection">
                                                        <label for="1" class="form-label">Prospection</label><br>
                                                    <?php endif; ?>

                                                    <?php if($decaissement->motif->libelle == "survey"): ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="survey" id="2" checked>
                                                        <label for="2" class="form-label">Survey</label><br>
                                                    <?php else: ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="survey" id="2">
                                                        <label for="2" class="form-label">Survey</label><br>
                                                    <?php endif; ?>

                                                    <?php if($decaissement->motif->libelle == "procedure administrative"): ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="procedure administrative" id="4" checked>
                                                        <label for="4" class="form-label">Procedure administrative</label><br>
                                                    <?php else: ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="procedure administrative" id="4">
                                                        <label for="4" class="form-label">Procedure administrative</label><br>
                                                    <?php endif; ?>

                                                    <?php if($decaissement->motif->libelle == "intervention"): ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="intervention" id="3" checked>
                                                        <label for="3" class="form-label">Intervention</label><br>
                                                    <?php else: ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="intervention" id="3">
                                                        <label for="3" class="form-label">Intervention</label><br>
                                                    <?php endif; ?>

                                                    <?php if($decaissement->motif->libelle == "livraison sur vente"): ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="livraison sur vente" id="5" checked>
                                                        <label for="5" class="form-label">Livraison sur vente</label><br>
                                                    <?php else: ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="livraison sur vente" id="5">
                                                        <label for="5" class="form-label">Livraison sur vente</label><br>
                                                    <?php endif; ?>

                                                    <?php if($decaissement->motif->libelle == "carburant"): ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="carburant" id="6" checked>
                                                        <label for="6" class="form-label">Carburant</label><br>
                                                    <?php else: ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="carburant" id="6">
                                                        <label for="6" class="form-label">Carburant</label><br>
                                                    <?php endif; ?>

                                                    <?php if($decaissement->motif->libelle == "communication"): ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="communication" id="7" checked>
                                                        <label for="7" class="form-label">Communication</label><br>
                                                    <?php else: ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="communication" id="7">
                                                        <label for="7" class="form-label">Communication</label><br>
                                                    <?php endif; ?>

                                                    <?php if($decaissement->motif->libelle == "autre"): ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="autre" id="autre">
                                                        <label for="autre" class="form-label">autre</label>
                                                    <?php else: ?>
                                                        <input type="radio" name="motif" class="form-check-input" value="autre" id="autre">
                                                        <label for="autre" class="form-label">autre</label>
                                                    <?php endif; ?>





                                                </div>

                                            </div>
                                            <div class="col-md-12">
                                              <label for="description" class="form-label">Décrire en quelques ligne le motif</label>
                                                <textarea name="description" id="description" cols="30" rows="10" class="form-control" style="height: 200px" required> <?php echo e($decaissement->motif->description); ?></textarea>
                                              </div>
                                            <div class="">
                                                <button type="submit" class="btn btn-success float-end">Valider</button>
                                              </div>
                                          </form><!-- End No Labels Form -->
                                        </div>
                                    </div>
                                </div>
                            </div><!-- End Vertically centered Modal-->

                            </div>

                          </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
              </div>
          </div>
          <!-- End Table with stripped rows -->
        </div>
      </div>
    </div>


<div class="modal fade" id="adddecaissement" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="card">
            <div class="modal-header">
                <div class="modal-title">
                    <h5> Décaissement</h5>

                </div>
                <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
        <div class="modal-body">
            <form class="row g-3 needs-validation" novalidate method="POST" action="<?php echo e(route('caisse.decaissement.store')); ?>">
                <?php echo csrf_field(); ?>
                <div>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class=""><?php echo e($message); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-12">
                    <label for="employe_id"  class="form-label">Nom du demandeur</label>
                    <select class="form-select" id="employe_id" name="employe_id[]" multiple="multiple" tabindex="1" required>
                        <?php $__currentLoopData = $employers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option  value="<?php echo e($employer->id); ?>" ><?php echo e($employer->nom." ".$employer->prenom); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-12">
                  <label for="code" class="form-label">Code</label>
                  <input type="number" id="code" name="code" class="form-control" placeholder="code" required>
                    
                </div>
                <div class="col-md-12">
                  <label for="somme" class="form-label">Montant</label>
                  <input type="number" id="somme" name="somme" class="form-control" placeholder="Montant" required>

                </div>
                
                <div class="col-md-12" >

                    <label class="form-label" for="">Motif(s)</label>
                    <div class="form-control p-3"  style="overflow: auto; height:130px">
                        <input type="radio" name="motif" class="form-check-input " id="Prospection" value="prospection">
                        <label for="Prospection" class="form-label">Prospection</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="survey" id="survey">
                        <label for="survey" class="form-label">Survey</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="intervention" id="intervention">
                        <label for="intervention" class="form-label">Intervention</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="procedure administrative" id="administrative">
                        <label for="administrative" class="form-label">Procedure administrative</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="livraison sur vente" id="livraison">
                        <label for="livraison" class="form-label">Livraison sur vente</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="carburant" id="carburant">
                        <label for="carburant" class="form-label">Carburant</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="communication" id="communication">
                        <label for="communication" class="form-label">Communication</label><br>
                        <input type="radio" name="motif" class="form-check-input" value="autre" id="autres">
                        <label for="autres" class="form-label">autre</label>
                    </div>

                </div>
                <div class="col-md-12">
                  <label for="description" class="form-label">Décrire en quelques ligne le motif</label>
                    <textarea name="description" id="description" cols="30" rows="10" class="form-control" style="height: 200px" required></textarea>
                  </div>
                <div class="">
                    <button type="submit" class="btn btn-success float-end">Valider</button>
                  </div>
              </form><!-- End No Labels Form -->
        </div>

      </div>
    </div>
  </div><!-- End Vertically centered Modal-->

</div>




</div>
</div>

<?php if(Session::has('message')): ?>

<script>
    toastr.success("<?php echo Session::get('message'); ?>");
</script>

<?php endif; ?>

<?php if(Session::has('cloture')): ?>

<script>
    toastr.error("<?php echo Session::get('cloture'); ?>");
</script>

<?php endif; ?>

<?php if($errors->all()): ?>

<script>
    toastr.error("Une erreur c'est produite");
</script>


<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobs-gestion28\resources\views/caisse/indexDecaissement.blade.php ENDPATH**/ ?>