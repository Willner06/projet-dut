<?php $__env->startSection('content'); ?>
    <div>
        <div class="pagetitle">
            <div class="">
                <h1><?php echo e($categorie->libelle); ?></h1>
                <div class="card float-end">
                    <button class="badge text-bg-success m-3" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalToggle-<?php echo e($categorie->id); ?>"> <i class="bi bi-plus-lg"></i> Produit </button>
                </div>
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </nav>
            <br><br>
            </div>

        </div><!-- End Page Title -->

        <div class="row">
            <?php $__currentLoopData = $categorie->marchandises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marchandise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3">
                    <div class="card rounded-4">
                        <div class="card-body">
                          <h5 class="card-title"><?php echo e($marchandise->designation); ?></h5>
                          <h6 class="card-subtitle mb-2 text-muted"><?php echo e($categorie->marchandises->first()->entres->count()); ?></h6>
                          <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>

                          <div class="float-end">
                            <a href="#" class="card-link text-bg-danger badge">Supprimer</a>
                            <a href="<?php echo e(route('marchandise.show', $marchandise->id)); ?>" class=" text-bg-warning badge">Voir</a>
                          </div>
                        </div>
                    </div><!-- End Card with titles, buttons, and links -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>



    <div class="modal fade" id="exampleModalToggle-<?php echo e($categorie->id); ?>" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-body">
                <form class="row g-3" method="post" action="<?php echo e(route('marchandise.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-12">
                        <label for="categorie" class="form-label">Catégorie</label>
                        <select class="form-select" id="categorie" name="categorie_id" required>
                          <option selected value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->libelle); ?></option>
                        </select>
                    </div>
                    <div class="col-md-12">
                      <label for="reference" class="form-label">Reference</label>
                      <input type="text" class="form-control" id="reference" name="reference" required>
                    </div>
                    <div class="col-md-12">
                      <label for="designation" class="form-label">Désignation</label>
                      <input type="text" class="form-control" id="designation" name="designation" required>
                    </div>
                    <div class="col-md-12">
                        <label for="prix_unitaire" class="form-label">Prix unitaire</label>
                        <input type="number" class="form-control" id="prix_unitaire" name="prix_unitaire" required>
                    </div>
                    <div class="col-12">
                      <button class="btn btn-success float-end" type="submit">Submit form</button>
                    </div>
                  </form>
            </div>
          </div>
        </div>
      </div>
      <div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2" tabindex="-1">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appMarchandise', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion6.2\resources\views/marchandise/categories/show.blade.php ENDPATH**/ ?>