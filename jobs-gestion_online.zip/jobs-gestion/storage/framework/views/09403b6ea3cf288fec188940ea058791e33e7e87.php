<?php

header("Content-type:application/vnd.ms-excel");
header("Content-Disposition:attachment;filename=$materiel->designation.xls");

header('Cache-Control: max-age=0');

?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <link href="<?php echo e(asset('img-jb-gestion/Logo_job_gestion.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('img-jb-gestion/Logo_job_gestion.png')); ?>" rel="apple-touch-icon">


  <title>JOBS GESTION</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('template/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/quill/quill.snow.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/quill/quill.bubble.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('template/vendor/simple-datatables/style.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>



  <!-- CSS -->



  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('template/css/style.css')); ?>" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.5.0
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>

    /* table{
        margin: 15px;
    } */

    table thead tr {
        border: 1px solid black;
        font-size: 25px;
    }

    table{
        border: 1px solid black;
    }

    table tbody tr td {
        border: 1px solid black;
    }
    .cout{
        float: right;
    }
    .categorie{
        background-color: rgb(21, 88, 233);
        color: #fff;
        text-align: center;
        font-size: 20px;
    }
    .materiel{
        background-color: rgb(207, 200, 200);
    }
    .tr-cout{
        background-color: #eef3dc
    }
    .cout-total{

    }

    .thead tr{
        background-color:rgb(240, 240, 50);
    }
</style>
</head>


<body>


    <div class="p-4">
        <div class="pagetitle">
            <div class="">
                <h1><?php echo e($materiel->designation); ?></h1>

                
                    
                
                <nav>
                    <ol class="breadcrumb">
                        
                        
                        
                    </ol>
                </nav>
            <br><br>
            </div>

        </div><!-- End Page Title -->

        <div class="row">
            

                <div >
                    <table class="">
                        <thead>
                            <tr>
                                <td colspan="7">
                                    <h4><u>Fiche d'immobilisation <?php echo e($materiel->designation); ?></u></h4>
                                </td>
                            </tr>
                        </thead>
                        <tbody class="">
                            <tr>
                                <td colspan="4">Code d'inventaire</td>
                                <td><?php echo e($materiel->code_inventaire); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Désignation</td>
                                <td><?php echo e($materiel->designation); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Type immobilisation</td>
                                <td><?php echo e($materiel->categorie->libelle); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Etat</td>
                                <td><?php echo e($materiel->etat); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Affectation</td>
                                <td><?php echo e($materiel->affectation); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Fournisseur</td>
                                <td><?php echo e($materiel->fournisseur); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <?php if(auth()->guard()->check()): ?>
                            <tr>
                                <td colspan="4">Date d'acaht ou de mise en service</td>
                                <td><?php echo e(Carbon\Carbon::parse($materiel->date_acquisition)->formatLocalized('%d %B %Y')); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Prix d'achat</td>
                                <td><?php echo e(number_format($materiel->prix_achat ,0,'.',' ').$monaie); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Autres frais</td>
                                <td><?php echo e(number_format($materiel->autres_frais ,0,'.',' ').$monaie); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">T V A</td>
                                <td><?php echo e(number_format($materiel->tva ,0,'.',' ').$monaie); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Coût d'acquisition TTC</td>
                                <td><?php echo e(number_format($materiel->cout_acquisitionTtc ,0,'.',' ').$monaie); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            
                            <tr>
                                <td colspan="7"><br></td>

                            </tr>
                            <tr>
                                <td colspan="4">BASE D'AMORTISSEMENT</td>
                                <td><?php echo e(number_format($materiel->base_ammortisable ,0,'.',' ').$monaie); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                
                                
                            </tr>
                            <tr>
                                <td colspan="4"> Mode d'amortissement</td>
                                <td><?php echo e($materiel->mode_ammortissement); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="4">Durée d'amortissement</td>
                                <td><?php echo e($materiel->duree_ammortissement); ?></td>
                                <td>Ans</td>
                                <td></td>
                                
                            </tr>
                            <tr>
                                <td colspan="7"><br></td>
                            </tr>
                            <tr class="bg-primary text-white text-center">
                                <td></td>
                                <td>ANNEE</td>
                                <td>BASE</td>
                                <td>TAUX</td>
                                <td>CALCUL DE L'AMORTISSEMENT</td>
                                <td>AMORT.</td>
                                <td>V.N.C</td>
                            </tr>


                            <tr class="text-center">
                                <td>
                                    <?php echo e($id); ?>

                                </td>
                                <td>
                                    <?php echo e($annee=Carbon\Carbon::parse($materiel->date_acquisition)->format('Y')); ?>

                                </td>
                                <td>
                                    <?php echo e(number_format($materiel->base_ammortisable,0,'.',' ') .$monaie); ?>

                                </td>
                                <td>
                                    <?php echo e(round($taux,0)."%"); ?>

                                </td>
                                <td><?php echo e(number_format(round($amortissement_premiere_annee,0),0,'.',' ') .$monaie); ?></td>
                                <td><?php echo e(number_format(round($amortissement_premiere_annee,0),0,'.',' ') .$monaie); ?></td>
                                <td><?php echo e(number_format($vncd=round($materiel->base_ammortisable - $amortissement_premiere_annee,0),0,'.',' ') .$monaie); ?></td>

                                <?php
                                    if (date('Y') == $annee) {
                                        $a_actuel=date('Y');
                                        $val=$vncd;
                                    }
                                    // else{
                                    //     $a_actuel=0;
                                    //     $val=0;
                                    // }
                                ?>

                            </tr>
                            <?php
                                round($vnc=$materiel->base_ammortisable - $amortissement_premiere_annee,0);
                                $id=2;
                                $annee=$annee+1;
                            ?>
                                <?php for($i = 1; $i < $materiel->duree_ammortissement; $i++): ?>

                                        <tr class="text-center">
                                            <td>
                                                <?php echo e($id++); ?>

                                            </td>
                                            <td>
                                                <?php echo e($an= $annee++); ?>

                                            </td>
                                            <td>
                                                <?php echo e(number_format(round($materiel->base_ammortisable,0),0,'.',' ') .$monaie); ?>

                                            </td>
                                            <td>
                                                <?php echo e(round($taux,0)."%"); ?>

                                            </td>
                                            <td><?php echo e(number_format(round($amortissement_annuel,0),0,'.',' ') .$monaie); ?></td>
                                            <td><?php echo e(number_format(round($amortissement_annuel,0),0,'.',' ') .$monaie); ?></td>
                                            <td><?php echo e(number_format(round(($vnc=$vnc-($amortissement_annuel)),0),0,'.',' ') .$monaie); ?></td>
                                        </tr>

                                        <?php
                                            if (date('Y') == $an) {
                                                $a_actuel=date('Y');
                                                $val=$vnc;
                                            }
                                            // else{
                                            //     $a_actuel=0;
                                            //     $val=0;
                                            // }
                                        ?>

                                <?php endfor; ?>




                                <tr class="text-center">
                                    <td>
                                        <?php echo e($id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($da=$annee); ?>

                                    </td>
                                    <td>
                                        <?php echo e(number_format(round($materiel->base_ammortisable,0),0,'.',' ') .$monaie); ?>

                                    </td>
                                    <td>
                                        <?php echo e(round($taux,0)."%"); ?>

                                    </td>
                                    <td><?php echo e(number_format(round($vnc,0),0,'.',' ') .$monaie); ?></td>
                                    <td><?php echo e(number_format(round($vnc,0),0,'.',' ') .$monaie); ?></td>
                                    <td><?php echo e(number_format(round($vncf=$vnc-$vnc,0),0,'.',' ') .$monaie); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="7"><br></td>
                                </tr>

                                <?php
                                    if (date('Y') >= $da) {
                                        $a_actuel=date('Y');
                                        $val=$vncf;
                                    }
                                    // else{
                                    //     $a_actuel=0;
                                    //     $val=0;
                                    // }
                                ?>


                                    <?php

                                    // if ($a_actuel != 0) {
                                        $p_cession =$materiel->prix_vente_valeur_reprise - $val;
                                    // }else{
                                    //     $p_cession=0;
                                    // }
                                    ?>

                                
                                <tr>
                                    <td colspan="7" class="text-center bg-danger text-white">
                                        CESSION, MISE AU REBUT, REINTEGRATION AU PATRIMOINE PERSONNEL :
                                    </td>
                                </tr>


                                <tr class="">
                                    <td colspan="4">
                                        Date de mise au rebut :
                                    </td>
                                    <?php if($materiel->date_mise_au_rebut==null): ?>
                                        <td></td>
                                    <?php else: ?>
                                        <td>
                                            <?php echo e(Carbon\Carbon::parse($materiel->date_mise_au_rebut)->formatLocalized('%d %B %Y')); ?>

                                        </td>
                                    <?php endif; ?>

                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        Date de cession :
                                    </td>
                                    <?php if($materiel->date_session==null): ?>
                                        <td></td>
                                    <?php else: ?>
                                        <td>
                                            <?php echo e(Carbon\Carbon::parse($materiel->date_session)->formatLocalized('%d %B %Y')); ?>

                                        </td>
                                    <?php endif; ?>

                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        Valeur Nette Comptable :
                                    </td>
                                    <td>
                                        <?php echo e(number_format($val,0,'.',' ') .$monaie); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        Prix de vente ou valeur de reprise :
                                    </td>
                                    <td>
                                        <?php echo e(number_format($materiel->prix_vente_valeur_reprise,0,'.',' ') .$monaie); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        <b><u>Plus-value globale prévisionnelle:</u></b>
                                    </td>
                                    <td>
                                        
                                        <?php echo e(number_format($p_cession,0,'.',' ') .$monaie); ?>

                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>


                                <tr class="">
                                    <td colspan="4">
                                        <b><u>Plus-value globale réelle:</u></b>
                                    </td>
                                    <td>
                                        <?php if($materiel->plus_value_globale != null): ?>
                                        <?php echo e(number_format($materiel->plus_value_globale,0,'.',' ') .$monaie); ?>

                                        <?php else: ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        Dont à COURT TERME :
                                    </td>
                                    <td>
                                        <?php echo e($materiel->dont_court_terme); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>

                                <tr class="">
                                    <td colspan="4">
                                        Dont à LONG TERME :
                                    </td>
                                    <td>
                                        <?php echo e($materiel->dont_long_terme); ?>

                                    </td>
                                    <td>
                                        
                                    </td>
                                    <td>
                                        
                                    </td>
                                </tr>
                                

                            <?php endif; ?>


                        </tbody>
                    </table>
                </div>
        </div>
    </div>



        <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

      <!-- Vendor JS Files -->
      <script src="<?php echo e(asset('template/vendor/apexcharts/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('template/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
      <script src="<?php echo e(asset('template/vendor/chart.js/chart.umd.js')); ?>"></script>
      <script src="<?php echo e(asset('template/vendor/echarts/echarts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('template/vendor/quill/quill.min.js')); ?>"></script>
      <script src="<?php echo e(asset('template/vendor/simple-datatables/simple-datatables.js')); ?>"></script>
      <script src="<?php echo e(asset('template/vendor/tinymce/tinymce.min.js')); ?>"></script>
      <script src="<?php echo e(asset('template/vendor/php-email-form/validate.js')); ?>"></script>

      <!-- Template Main JS File -->
      <script src="<?php echo e(asset('template/js/main.js')); ?>"></script>
      <!-- Template Main JS File -->
      
      


    <!-- JS -->
    

    </body>

</html>
<?php /**PATH /home/u408137398/domains/jobs-conseil.tech/public_html/jobsgestion/resources/views/immobilisation/csvMateriel.blade.php ENDPATH**/ ?>