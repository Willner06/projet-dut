<?php $__env->startSection('content'); ?>

<style>
    .carte{
        cursor: pointer;
        box-shadow: 1px 1px 10px black;
    }

    #transportDuMois{
        display: block;

    }

    #transportSurvey{
        display: none;
    }

    #transportProspection{
        display: none;
    }

    #transportLivraison{
        display: none;
    }

    #transportProcedure{
        display: none;
    }

    #transportIntervention{
        display: none;
    }
</style>
    
    <section>
        <div class="card">
            <div class="row container" >
                <div>
                    <h5 class="w-25 m-3 float-end">
                        <div class="search-bar header">
                            <form class="search-form d-flex align-items-center" method="POST" action="<?php echo e(route('caisse.decaissement.searchTransport')); ?>">
                                <?php echo csrf_field(); ?>
                              <input type="month" name="query" placeholder="Search" title="Entrez le mois recherché" max="<?php echo e(date("Y-m")); ?>" required>
                              <button type="submit" title="Search"><i class="bi bi-search"></i></button>
                            </form>
                          </div><!-- End Search Bar -->
                    </h5>
                </div>
                <div class="card col-sm-3 ms-4 me-5 carte" onclick="getLivraison()">
                    <div class="card-title">
                        <div >
                            Livraisons
                            <img class="float-end pe-3"  src="<?php echo e(asset('icons/fast-delivery.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="container d-flex">
                        <h4 class="w-25 float-end ps-"><?php echo e(count($livraisons)); ?></h4>
                        <h5 class="float-end w-75 pt-1" style="color: #71d1f5"><?php echo e(number_format($totalLivraisons ,0,'.',' ').$monaie); ?></h5>
                    </div>
                </div>
                <div class="card col-sm-3 ms-4 me-5 carte" onclick="getSurvey()">
                    <div class="card-title">
                        <div >
                            Survey
                            <img class="float-end pe-3"  src="<?php echo e(asset('icons/shopping-list.png')); ?>" alt="">

                        </div>
                    </div>
                    <div class="container d-flex">
                        <h4 class="w-25 float-end ps-"><?php echo e(count($surveys)); ?></h4>
                        <h5 class="float-end w-75 pt-1" style="color: #71d1f5"><?php echo e(number_format($totalSurveys,0,'.',' ').$monaie); ?></h5>
                    </div>
                </div>
                <div class="card col-sm-3 ms-4 me-5 carte" onclick="getProspection()">
                    <div class="card-title">
                        <div >
                            Prospection
                            <img class="float-end pe-3"  src="<?php echo e(asset('icons/searching.png')); ?>" alt="">

                        </div>
                    </div>
                    <div class="container d-flex">
                        <h4 class="w-25 float-end ps-"><?php echo e(count($prospections)); ?></h4>
                        <h5 class="float-end w-75 pt-1" style="color: #71d1f5"><?php echo e(number_format($totalProspections,0,'.',' ').$monaie); ?></h5>
                    </div>
                </div>
                <div class="card col-sm-3 ms-4 me-5 carte" onclick="getProcedure()">
                    <div class="card-title">
                        <div >
                            Procedures administratives
                        </div>
                    </div>
                    <div class="container d-flex">
                        <h4 class="w-25 float-end ps-"><?php echo e(count($procedures)); ?></h4>
                        <h5 class="float-end w-75 pt-1" style="color: #71d1f5"><?php echo e(number_format($totalProcedures,0,'.',' ').$monaie); ?></h5>
                    </div>
                </div>
                <div class="card col-sm-3 ms-4 me-5 carte" onclick="getIntervention()">
                    <div class="card-title">
                        <div >
                            Interventions
                        </div>
                    </div>
                    <div class="container d-flex">
                        <h4 class="w-25 float-end ps-"><?php echo e(count($interventions)); ?></h4>
                        <h5 class="float-end w-75 pt-1" style="color: #71d1f5"><?php echo e(number_format($totalInterventions,0,'.',' ').$monaie); ?></h5>
                    </div>
                </div>
                <div class="card col-sm-3 ms-4 me-5 carte" onclick="getTotal()">
                    <div class="card-title">
                        <div >
                            Total
                        </div>
                    </div>
                    <div class="container d-flex">
                        <h4 class="w-25 float-end ps-"><?php echo e(count($transportDuMois)); ?></h4>
                        <h5 class="float-end w-75 pt-1" style="color: #71d1f5"><?php echo e(number_format($total,0,'.',' ').$monaie); ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="card mt-3 p-2 table-responsive" id="transportDuMois">
            <h4 class="m-4">Décaissements liés au transport du mois de <u class="text-danger"><?php echo e($date); ?></u></h4>
            <table class="text-center table table-striped table-hover">
                <thead>
                    <tr >
                        <th>Date</th>
                        <th>N° Piece</th>
                        <th>Motif</th>
                        <th>Description</th>
                        <th>Montant</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transportDuMois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($transport->created_at->format('d/M/y')); ?></td>
                        <td><?php echo e($transport->num_piece); ?></td>
                        <td><?php echo e($transport->motif->libelle); ?></td>
                        <td><?php echo e($transport->motif->description); ?></td>
                        <td><?php echo e(number_format($transport->somme,0,'.',' ').$monaie); ?></td>
                        <td>
                            <a class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal-<?php echo e($transport->id); ?>">Voir</a>
                        </td>
                    </tr>



  <!-- Modal -->
  <div class="modal modal-fullscreen-lg-down" id="exampleModal-<?php echo e($transport->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel"><?php echo e($transport->num_piece); ?></h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body row">
            <div class="card m-2" style="width: 14rem;">
                <div class="card-body">
                    <div>
                        <h5 class="card-title">Somme alouée</h5>
                        <p class="card-text ms-3"><?php echo e(number_format($transport->somme,0,'.',' ').$monaie); ?></p>
                    </div>
                </div>
            </div>

            <div class="card m-2" style="width: 14rem;">
                <div class="card-body">
                    <div>
                    <h5 class="card-title">Motifs</h5>
                    <h5><?php echo e($transport->motif->libelle); ?></h5>
                    </div>
                </div>

            </div>

            <div class="card m-2" style="width: 29rem;">
                <div class="card-body">
                    <div>
                        <h5 class="card-title">Description</h5>
                        <p class="card-text ms-3"><?php echo e($transport->motif->description); ?></p>
                    </div>
                </div>
            </div>
        </div>

      </div>
    </div>
  </div>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>



    <div class="card mt-3 p-2 table-responsive" id="transportSurvey">
        <div class="card-title">
            <h3>Surveys du mois de <?php echo e($date); ?></h3>
        </div>
        <table class="text-center table table-striped table-hover">
            <thead>
                <tr >
                    <th>Date</th>
                    <th>N° Piece</th>
                    <th>Description</th>
                    <th>Montant</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($survey->created_at->format('d/M/y')); ?></td>
                    <td><?php echo e($survey->num_piece); ?></td>
                    <td><?php echo e($survey->motif->description); ?></td>
                    <td><?php echo e($survey->somme); ?></td>
                    <td>
                        <a class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalSurvey-<?php echo e($survey->id); ?>">Voir</a>
                    </td>
                </tr>



<!-- Modal -->
<div class="modal modal-fullscreen-lg-down" id="modalSurvey-<?php echo e($survey->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog">
  <div class="modal-content">
    <div class="modal-header">
      <h1 class="modal-title fs-5" id="exampleModalLabel"><?php echo e($survey->num_piece); ?></h1>
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body row">
        <div class="card m-2" style="width: 14rem;">
            <div class="card-body">
                <div>
                    <h5 class="card-title">Somme alouée</h5>
                    <p class="card-text ms-3"><?php echo e(number_format($survey->somme,0,'.',' ').$monaie); ?></p>
                </div>
            </div>
        </div>

        <div class="card m-2" style="width: 14rem;">
            <div class="card-body">
                <div>
                <h5 class="card-title">Motif</h5>
                
                    <h5><?php echo e($survey->motif->libelle); ?></h5>
                
                </div>
            </div>

        </div>

        <div class="card m-2" style="width: 29rem;">
            <div class="card-body">
                <div>
                    <h5 class="card-title">Description</h5>
                    <p class="card-text ms-3"><?php echo e($survey->motif->description); ?></p>
                </div>
            </div>
        </div>
    </div>

  </div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>





<div class="card mt-3 p-2 table-responsive" id="transportProspection">
    <div class="card-title">
        <h3>Prospections du mois de <?php echo e($date); ?></h3>
    </div>
    <table class="text-center table table-striped table-hover">
        <thead>
            <tr >
                <th>Date</th>
                <th>N° Piece</th>
                <th>Description</th>
                <th>Montant</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $prospections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prospection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($prospection->created_at->format('d/M/y')); ?></td>
                <td><?php echo e($prospection->num_piece); ?></td>
                <td><?php echo e($prospection->motif->description); ?></td>
                <td><?php echo e($prospection->somme); ?></td>
                <td>
                    <a class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalprospection-<?php echo e($prospection->id); ?>">Voir</a>
                </td>
            </tr>



<!-- Modal -->
<div class="modal modal-fullscreen-lg-down" id="modalprospection-<?php echo e($prospection->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel"><?php echo e($prospection->num_piece); ?></h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body row">
    <div class="card m-2" style="width: 14rem;">
        <div class="card-body">
            <div>
                <h5 class="card-title">Somme alouée</h5>
                <p class="card-text ms-3"><?php echo e(number_format($prospection->somme,0,'.',' ').$monaie); ?></p>
            </div>
        </div>
    </div>

    <div class="card m-2" style="width: 14rem;">
        <div class="card-body">
            <div>
            <h5 class="card-title">Motifs</h5>
            <h5><?php echo e($prospection->motif->libelle); ?></h5>

            </div>
        </div>

    </div>

    <div class="card m-2" style="width: 29rem;">
        <div class="card-body">
            <div>
                <h5 class="card-title">Description</h5>
                <p class="card-text ms-3"><?php echo e($prospection->motif->description); ?></p>
            </div>
        </div>
    </div>
</div>

</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>





<div class="card mt-3 p-2 table-responsive" id="transportIntervention">
    <div class="card-title">
        <h3>Interventions du mois de <?php echo e($date); ?></h3>
    </div>
    <table class="text-center table table-striped table-hover">
        <thead>
            <tr >
                <th>Date</th>
                <th>N° Piece</th>
                <th>Description</th>
                <th>Montant</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $interventions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intervention): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($intervention->created_at->format('d/M/y')); ?></td>
                <td><?php echo e($intervention->num_piece); ?></td>
                <td><?php echo e($intervention->motif->description); ?></td>
                <td><?php echo e($intervention->somme); ?></td>
                <td>
                    <a class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalintervention-<?php echo e($intervention->id); ?>">Voir</a>
                </td>
            </tr>



<!-- Modal -->
<div class="modal modal-fullscreen-lg-down" id="modalintervention-<?php echo e($intervention->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel"><?php echo e($intervention->num_piece); ?></h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body row">
    <div class="card m-2" style="width: 14rem;">
        <div class="card-body">
            <div>
                <h5 class="card-title">Somme alouée</h5>
                <p class="card-text ms-3"><?php echo e(number_format($intervention->somme,0,'.',' ').$monaie); ?></p>
            </div>
        </div>
    </div>

    <div class="card m-2" style="width: 14rem;">
        <div class="card-body">
            <div>
            <h5 class="card-title">Motifs</h5>
            <h5><?php echo e($intervention->motif->libelle); ?></h5>

            </div>
        </div>

    </div>

    <div class="card m-2" style="width: 29rem;">
        <div class="card-body">
            <div>
                <h5 class="card-title">Description</h5>
                <p class="card-text ms-3"><?php echo e($intervention->motif->description); ?></p>
            </div>
        </div>
    </div>
</div>

</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>





<div class="card mt-3 p-2 table-responsive" id="transportLivraison">
    <div class="card-title">
        <h3>Livraisons du mois de <?php echo e($date); ?></h3>
    </div>
    <table class="text-center table table-striped table-hover">
        <thead>
            <tr >
                <th>Date</th>
                <th>N° Piece</th>
                <th>Description</th>
                <th>Montant</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $livraisons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livraison): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($livraison->created_at->format('d/M/y')); ?></td>
                <td><?php echo e($livraison->num_piece); ?></td>
                <td><?php echo e($livraison->motif->description); ?></td>
                <td><?php echo e($livraison->somme); ?></td>
                <td>
                    <a class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modallivraison-<?php echo e($livraison->id); ?>">Voir</a>
                </td>
            </tr>



<!-- Modal -->
<div class="modal modal-fullscreen-lg-down" id="modallivraison-<?php echo e($livraison->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel"><?php echo e($livraison->num_piece); ?></h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body row">
    <div class="card m-2" style="width: 14rem;">
        <div class="card-body">
            <div>
                <h5 class="card-title">Somme alouée</h5>
                <p class="card-text ms-3"><?php echo e(number_format($livraison->somme,0,'.',' ').$monaie); ?></p>
            </div>
        </div>
    </div>

    <div class="card m-2" style="width: 14rem;">
        <div class="card-body">
            <div>
            <h5 class="card-title">Motifs</h5>
            <h5><?php echo e($livraison->motif->libelle); ?></h5>

            </div>
        </div>

    </div>

    <div class="card m-2" style="width: 29rem;">
        <div class="card-body">
            <div>
                <h5 class="card-title">Description</h5>
                <p class="card-text ms-3"><?php echo e($livraison->motif->description); ?></p>
            </div>
        </div>
    </div>
</div>

</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>





<div class="card mt-3 p-2 table-responsive" id="transportProcedure">
    <div class="card-title">
        <h3>Procedures administratives du mois de <?php echo e($date); ?></h3>
    </div>
    <table class="text-center table table-striped table-hover">
        <thead>
            <tr >
                <th>Date</th>
                <th>N° Piece</th>
                <th>Description</th>
                <th>Montant</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $procedures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($procedure->created_at->format('d/M/y')); ?></td>
                <td><?php echo e($procedure->num_piece); ?></td>
                <td><?php echo e($procedure->motif->description); ?></td>
                <td><?php echo e($procedure->somme); ?></td>
                <td>
                    <a class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalprocedure-<?php echo e($procedure->id); ?>">Voir</a>
                </td>
            </tr>



<!-- Modal -->
<div class="modal modal-fullscreen-lg-down" id="modalprocedure-<?php echo e($procedure->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel"><?php echo e($procedure->num_piece); ?></h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body row">
    <div class="card m-2" style="width: 14rem;">
        <div class="card-body">
            <div>
                <h5 class="card-title">Somme alouée</h5>
                <p class="card-text ms-3"><?php echo e(number_format($procedure->somme,0,'.',' ').$monaie); ?></p>
            </div>
        </div>
    </div>

    <div class="card m-2" style="width: 14rem;">
        <div class="card-body">
            <div>
            <h5 class="card-title">Motifs</h5>
            <h5><?php echo e($procedure->motif->libelle); ?></h5>

            </div>
        </div>

    </div>

    <div class="card m-2" style="width: 29rem;">
        <div class="card-body">
            <div>
                <h5 class="card-title">Description</h5>
                <p class="card-text ms-3"><?php echo e($procedure->motif->description); ?></p>
            </div>
        </div>
    </div>
</div>

</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

</section>





<script>

function getTotal(){
        $('#transportDuMois').show();
        $('#transportSurvey').hide();
        $('#transportLivraison').hide();
        $('#transportProspection').hide();
        $('#transportProcedure').hide();
        $('#transportIntervention').hide();
    }

    function getSurvey(){
        $('#transportDuMois').hide();
        $('#transportSurvey').show();
        $('#transportLivraison').hide();
        $('#transportProspection').hide();
        $('#transportProcedure').hide();
        $('#transportIntervention').hide();
    }

    function getLivraison(){
        $('#transportDuMois').hide();
        $('#transportSurvey').hide();
        $('#transportLivraison').show();
        $('#transportProspection').hide();
        $('#transportProcedure').hide();
        $('#transportIntervention').hide();
    }

    function getProspection(){
        $('#transportDuMois').hide();
        $('#transportSurvey').hide();
        $('#transportLivraison').hide();
        $('#transportProspection').show();
        $('#transportProcedure').hide();
        $('#transportIntervention').hide();
    }

    function getProcedure(){
        $('#transportDuMois').hide();
        $('#transportSurvey').hide();
        $('#transportLivraison').hide();
        $('#transportProspection').hide();
        $('#transportProcedure').show();
        $('#transportIntervention').hide();
    }

    function getIntervention(){
        $('#transportDuMois').hide();
        $('#transportSurvey').hide();
        $('#transportLivraison').hide();
        $('#transportProspection').hide();
        $('#transportProcedure').hide();
        $('#transportIntervention').show();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developpeur\Documents\jb\jobs-gestion5.8\resources\views/caisse/ficheTransport.blade.php ENDPATH**/ ?>