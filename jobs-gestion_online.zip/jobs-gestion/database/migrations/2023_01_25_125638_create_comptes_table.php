<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('comptes', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('decaissement')->nullable();
            $table->bigInteger('encaissement')->nullable();
            $table->bigInteger('solde')->nullable();
            $table->bigInteger('solde_theorique')->nullable();
            $table->foreignId('cloture_id')->constrained('clotures')->OnDelete('cascade');
            $table->timestamps();

            $table->engine = 'InnoDB';
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('comptes');
    }
};
