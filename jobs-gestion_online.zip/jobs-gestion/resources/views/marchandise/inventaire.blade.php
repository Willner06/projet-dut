@extends('layouts.appMarchandise')
@section('content')

    <h1>inventaire</h1>

@endsection
