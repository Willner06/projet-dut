@extends('layouts.appMarchandise')
@section('content')

<h1>dashboard</h1>


@endsection
